"""
SQL types for CQL to SQL translation.

This module defines dataclasses for representing generated SQL fragments
with proper precedence handling for parenthesization, as well as context
types for tracking translation state.
"""

from __future__ import annotations

import re
from dataclasses import dataclass, field, fields, is_dataclass
from typing import Any, Dict, List, Optional, Union

from .column_generation import (
    ColumnDefinition,
    build_column_definitions,
    get_default_property_paths,
)
from .temporal_fields import TEMPORAL_BOUND_COLUMN_NAMES
from .fhirpath_builder import escape_fhirpath_string_literal
from ..errors import TranslationError


# SQL reserved words that must be quoted when used as identifiers/aliases
_SQL_RESERVED_WORDS = {
    "NULL", "TRUE", "FALSE", "SELECT", "FROM", "WHERE",
    "AND", "OR", "NOT", "IN", "IS", "LIKE", "BETWEEN",
    "EXISTS", "CASE", "WHEN", "THEN", "ELSE", "END",
    "JOIN", "LEFT", "RIGHT", "INNER", "OUTER", "ON",
    "GROUP", "BY", "HAVING", "ORDER", "ASC", "DESC",
    "LIMIT", "OFFSET", "UNION", "INTERSECT", "EXCEPT",
    "DISTINCT", "ALL", "AS", "WITH", "RECURSIVE",
    "TYPE", "TABLE", "INDEX", "CREATE", "DROP", "ALTER",
    "INSERT", "UPDATE", "DELETE", "SET", "VALUES",
    "PRIMARY", "KEY", "REFERENCES", "CHECK", "DEFAULT",
    "CAST", "FILTER", "OVER", "PARTITION", "WINDOW",
    "CURRENT", "ROW", "ROWS", "RANGE", "INTERVAL",
}

_CODING_EXISTS_RE = re.compile(
    r"^(?P<path>[A-Za-z][A-Za-z0-9_.]*)\.coding\.where\("
    r"\s*system\s*=\s*'(?P<system>[^']+)'\s+and\s+code\s*=\s*'(?P<code>[^']+)'\s*"
    r"\)\.exists\(\)$"
)


def _same_sql_expression(left: "SQLExpression", right: "SQLExpression") -> bool:
    """Compare small AST expressions by rendered SQL for normalization guards."""
    return left.to_sql() == right.to_sql()


def _extract_to_interval_case_source(expr: "SQLCase") -> Optional["SQLExpression"]:
    """Return the source column for CASE produced by fluent toInterval()."""
    if not expr.when_clauses or not isinstance(expr.else_clause, SQLFunctionCall):
        return None
    if expr.else_clause.name != "intervalFromBounds" or len(expr.else_clause.args) < 2:
        return None

    source = expr.else_clause.args[0]
    if not _same_sql_expression(source, expr.else_clause.args[1]):
        return None

    for _, result in expr.when_clauses:
        if isinstance(result, SQLNull) or (
            isinstance(result, SQLLiteral) and result.value is None
        ):
            continue
        if not _same_sql_expression(result, source):
            return None
    return source


def _is_null_expression(expr: Optional["SQLExpression"]) -> bool:
    return isinstance(expr, SQLNull) or (
        isinstance(expr, SQLLiteral) and expr.value is None
    )


def _extract_interval_bound_expression(
    expr: "SQLExpression",
    bound_name: str,
) -> Optional["SQLExpression"]:
    """Return the known bound expression for an interval-producing expression."""
    if isinstance(expr, SQLFunctionCall) and expr.name == "intervalFromBounds" and len(expr.args) >= 2:
        return expr.args[0] if bound_name == "intervalStart" else expr.args[1]
    if _is_null_expression(expr):
        return SQLNull()
    return None


def _fold_interval_bound_case(
    expr: "SQLCase",
    bound_name: str,
) -> Optional["SQLCase"]:
    """Fold intervalStart/End(CASE ... intervalFromBounds ... END)."""
    folded_when_clauses = []
    changed = False

    for condition, result in expr.when_clauses:
        folded_result = _extract_interval_bound_expression(result, bound_name)
        if folded_result is None:
            return None
        changed = changed or folded_result is not result
        folded_when_clauses.append((condition, folded_result))

    folded_else = None
    if expr.else_clause is not None:
        folded_else = _extract_interval_bound_expression(expr.else_clause, bound_name)
        if folded_else is None:
            return None
        changed = changed or folded_else is not expr.else_clause

    if not changed:
        return None
    return SQLCase(
        when_clauses=folded_when_clauses,
        else_clause=folded_else,
        operand=expr.operand,
    )


def _try_coding_match_call(call: "SQLFunctionCall") -> Optional["SQLExpression"]:
    """Rewrite simple coding existence FHIRPath checks to a dedicated UDF."""
    if call.name.lower() != "fhirpath_bool" or len(call.args) != 2:
        return None
    path_arg = call.args[1]
    if not isinstance(path_arg, SQLLiteral) or not isinstance(path_arg.value, str):
        return None

    match = _CODING_EXISTS_RE.match(path_arg.value)
    if not match:
        return None

    return SQLFunctionCall(
        name="coding_matches",
        args=[
            call.args[0],
            SQLLiteral(value=match.group("path")),
            SQLLiteral(value=match.group("system")),
            SQLLiteral(value=match.group("code")),
        ],
    )


# Operator precedence levels (higher = binds tighter)
PRECEDENCE = {
    # Set operators (lowest — standard SQL: INTERSECT > UNION/EXCEPT)
    "UNION": 0,  # UNION/UNION ALL
    "UNION_ALL": 0,
    "EXCEPT": 0,
    "INTERSECT": 1,  # INTERSECT binds tighter than UNION/EXCEPT
    # Logical operators (lowest)
    "OR": 2,
    "AND": 3,
    "NOT": 4,
    # Comparison operators
    "=": 5,
    "!=": 5,
    "<>": 5,
    "<": 5,
    "<=": 5,
    ">": 5,
    ">=": 5,
    "IS": 5,
    "IS NOT": 5,
    "IN": 5,
    "NOT IN": 5,
    "LIKE": 5,
    "BETWEEN": 5,
    # Additive operators
    "+": 6,
    "-": 6,
    "||": 6,  # String concatenation
    # Multiplicative operators
    "*": 7,
    "/": 7,
    "%": 7,
    # Unary operators
    "UNARY_MINUS": 8,
    "UNARY_PLUS": 8,
    # Function call, subscript
    "FUNCTION": 9,
    "SUBSCRIPT": 9,
    # Primary (highest)
    "PRIMARY": 11,
}


@dataclass
class SQLExpression:
    """
    Base class for SQL expression fragments.

    All SQL fragments inherit from this class to provide
    common interface for SQL generation.

    Note: precedence should be set by subclasses in __post_init__.
    """

    # Tracks half-open interval boundaries (e.g., "end of" produces exclusive upper bound)
    is_exclusive_boundary: bool = field(default=False, init=False, repr=False)

    # Optional type hint for the expression's result (e.g., "Quantity")
    result_type: Optional[str] = field(default=None, init=False, repr=False)

    # Class-level default, not a dataclass field
    @property
    def precedence(self) -> int:
        """Get precedence level for this expression."""
        return PRECEDENCE["PRIMARY"]

    def to_sql(self, parent_precedence: int = 0) -> str:
        """
        Generate SQL string for this expression.

        Args:
            parent_precedence: The precedence of the parent expression
                              (used to determine if parentheses are needed).

        Returns:
            The SQL string representation.
        """
        raise NotImplementedError("Subclasses must implement to_sql()")

    def needs_parentheses(self, parent_precedence: int) -> bool:
        """Check if this expression needs parentheses based on parent precedence."""
        return self.precedence < parent_precedence

    def is_date_typed(self) -> bool:
        """Check if this expression produces a DATE-typed value.

        Returns True for SQLCast(..., target_type="DATE") or SQLRaw containing
        a DATE literal (e.g. "DATE '2024-01-01'"). Used to detect when
        intervalFromBounds arguments need CAST to VARCHAR.
        """
        return False


@dataclass
class SQLLiteral(SQLExpression):
    """
    Represents a literal value in SQL.

    Examples:
        123
        'hello'
        TRUE
        NULL
    """

    value: Union[str, int, float, bool, None]
    sql_type: Optional[str] = None  # 'string', 'integer', 'decimal', 'boolean', 'null'
    raw_sql: Optional[str] = None
    precedence: int = field(default=PRECEDENCE["PRIMARY"], init=False)

    def __post_init__(self):
        self.precedence = PRECEDENCE["PRIMARY"]

    def to_sql(self, parent_precedence: int = 0) -> str:
        if self.raw_sql is not None:
            return self.raw_sql
        if self.value is None:
            return "NULL"
        elif isinstance(self.value, bool):
            return "TRUE" if self.value else "FALSE"
        elif isinstance(self.value, str):
            # Escape single quotes
            escaped = self.value.replace("'", "''")
            return f"'{escaped}'"
        elif isinstance(self.value, float):
            # Handle special float values
            if self.value == float("inf"):
                return "'Infinity'"
            elif self.value == float("-inf"):
                return "'-Infinity'"
            elif self.value != self.value:  # NaN
                return "'NaN'"
            return str(self.value)
        else:
            return str(self.value)


@dataclass
class SQLRaw(SQLExpression):
    """
    Represents raw SQL that should not be escaped or quoted.

    Use for SQL fragments that need to be passed through verbatim,
    such as INTERVAL literals: INTERVAL '1 day'

    WARNING: Use with caution - this bypasses all escaping!
    """

    raw_sql: str
    precedence: int = field(default=PRECEDENCE["PRIMARY"], init=False)

    def __post_init__(self):
        self.precedence = PRECEDENCE["PRIMARY"]

    def to_sql(self, parent_precedence: int = 0) -> str:
        return self.raw_sql

    def is_date_typed(self) -> bool:
        """Check if this raw SQL is a DATE literal (e.g. DATE '2024-01-01')."""
        return self.raw_sql.startswith("DATE ")


@dataclass
class SQLNamedArg(SQLExpression):
    """
    Represents a named argument in a function call: name := value.
    Used for DuckDB's struct_pack(key := value, ...) syntax.
    """

    name: str
    value: "SQLExpression" = None
    precedence: int = field(default=PRECEDENCE["PRIMARY"], init=False)

    def __post_init__(self):
        self.precedence = PRECEDENCE["PRIMARY"]

    def to_sql(self, parent_precedence: int = 0) -> str:
        return f"{self.name} := {self.value.to_sql()}"


@dataclass
class SQLExtract(SQLExpression):
    """
    Represents SQL EXTRACT(field FROM expr) which has special syntax
    (no comma between field and FROM).

    Examples:
        EXTRACT(YEAR FROM date_col)
        EXTRACT(MONTH FROM timestamp_col)
    """

    extract_field: str  # YEAR, MONTH, DAY, etc.
    source: "SQLExpression" = None
    precedence: int = 0

    def __post_init__(self):
        self.precedence = PRECEDENCE["PRIMARY"]

    def to_sql(self, parent_precedence: int = 0) -> str:
        # Wrap source in TRY_CAST to TIMESTAMP to handle VARCHAR ISO 8601
        # strings from CQL precision-preserving datetime representation.
        src = self.source.to_sql()
        return f"EXTRACT({self.extract_field} FROM TRY_CAST({src} AS TIMESTAMP))"


@dataclass
class SQLIdentifier(SQLExpression):
    """
    Represents an identifier (column, table, alias) in SQL.

    Examples:
        patient_id
        resource
        t1.name
    """

    name: str
    quoted: bool = False
    precedence: int = PRECEDENCE["PRIMARY"]

    def to_sql(self, parent_precedence: int = 0) -> str:
        # Auto-quote if name contains spaces, special characters, or is a reserved word
        needs_quoting = (
            self.quoted or
            ' ' in self.name or
            any(c in self.name for c in '-()') or
            self.name.upper() in _SQL_RESERVED_WORDS
        )
        if needs_quoting:
            # Use double quotes for quoted identifiers (escape internal quotes)
            escaped = self.name.replace('"', '""')
            return f'"{escaped}"'
        return self.name


@dataclass
class SQLQualifiedIdentifier(SQLExpression):
    """
    Represents a qualified identifier (table.column) in SQL.

    Examples:
        t1.resource
        patients.id
    """

    parts: List[str] = field(default_factory=list)
    precedence: int = PRECEDENCE["PRIMARY"]

    def to_sql(self, parent_precedence: int = 0) -> str:
        def _quote_part(part: str) -> str:
            """Quote a part if it contains special characters needing quoting."""
            if part.startswith('"') and part.endswith('"'):
                return part  # already quoted
            needs_quoting = (
                ' ' in part or ':' in part or '-' in part or
                '(' in part or ')' in part or '"' in part or '.' in part
            )
            if needs_quoting:
                # Escape embedded double quotes per SQL identifier rules so
                # a quote can never terminate the identifier early.
                return '"' + part.replace('"', '""') + '"'
            return part
        return ".".join(_quote_part(p) for p in self.parts)


@dataclass
class SQLFunctionCall(SQLExpression):
    """
    Represents a function call in SQL.

    Examples:
        fhirpath_text(resource, 'name')
        COALESCE(a, b)
        COUNT(*)
    """

    name: str
    args: List[SQLExpression] = field(default_factory=list)
    distinct: bool = False
    order_by: Optional[List[tuple]] = None  # [(expr, 'ASC'|'DESC')] for ordered aggregates
    precedence: int = PRECEDENCE["FUNCTION"]

    def normalize(self) -> "SQLExpression":
        """Pre-serialization normalization: apply domain-specific transforms.

        Returns a new expression (possibly different type) that is safe for
        pure SQL serialization.  Callers who need special handling should
        call ``normalize().to_sql()`` instead of ``to_sql()`` directly.
        The default ``to_sql()`` calls this internally for backward compatibility.
        """
        coding_match_call = _try_coding_match_call(self)
        if coding_match_call is not None:
            return coding_match_call

        # Use precomputed retrieve CTE temporal bounds when intervalStart/End
        # receives a known temporal column such as Encounter.period or
        # Observation.effective.
        if self.name in ("intervalStart", "intervalEnd") and len(self.args) == 1:
            arg = self.args[0]
            if isinstance(arg, SQLCase):
                folded_case = _fold_interval_bound_case(arg, self.name)
                if folded_case is not None:
                    return folded_case
                arg = _extract_to_interval_case_source(arg) or arg
            if isinstance(arg, SQLFunctionCall) and arg.name == "intervalFromBounds" and len(arg.args) >= 2:
                return arg.args[0] if self.name == "intervalStart" else arg.args[1]
            if isinstance(arg, SQLQualifiedIdentifier) and len(arg.parts) >= 2:
                col_name = arg.parts[-1]
                if (
                    col_name in TEMPORAL_BOUND_COLUMN_NAMES
                    and not col_name.endswith(("_start", "_end"))
                ):
                    suffix = "start" if self.name == "intervalStart" else "end"
                    return SQLQualifiedIdentifier(parts=arg.parts[:-1] + [f"{col_name}_{suffix}"])

        # array_length on non-array arguments → CASE IS NOT NULL / CASE WHEN
        # SQLRaw used here: normalize() is called only from to_sql() (final rendering).
        if self.name.lower() == "array_length" and len(self.args) >= 1:
            arg = self.args[0]
            if isinstance(arg, SQLCase):
                arg_sql = arg.to_sql()
                return SQLRaw(f"(CASE WHEN ({arg_sql}) IS NOT NULL THEN 1 ELSE 0 END)")
            if isinstance(arg, SQLBinaryOp) and arg.operator in ("IS NOT", "IS", "=", "<>", "!=", "<", ">", "<=", ">="):
                arg_sql = arg.to_sql()
                return SQLRaw(f"(CASE WHEN ({arg_sql}) THEN 1 ELSE 0 END)")

        # fhirpath functions with SQLUnion first arg → distribute via COALESCE
        if self.name.lower() in ("fhirpath_text", "fhirpath_bool", "fhirpath_date") and len(self.args) >= 1:
            first_arg = self.args[0]
            if isinstance(first_arg, SQLUnion):
                coalesce_args = [
                    SQLFunctionCall(name=self.name, args=[op] + self.args[1:], distinct=self.distinct)
                    for op in first_arg.operands
                ]
                return SQLFunctionCall(name="COALESCE", args=coalesce_args)

        # fhirpath_date returns DATE, but CQL temporal values are now VARCHAR
        # ISO 8601 strings.  Wrap in CAST(... AS VARCHAR) for type compatibility
        # in COALESCE, comparisons, and other mixed-type contexts.
        if self.name.lower() == "fhirpath_date":
            arg_sqls = [a.to_sql() for a in self.args]
            return SQLRaw(f"CAST(fhirpath_date({', '.join(arg_sqls)}) AS VARCHAR)")

        # Numeric aggregates (SUM, AVG, etc.) may receive VARCHAR columns from
        # CQL DurationBetween or temporal expressions.  Wrap in TRY_CAST(... AS DOUBLE)
        # so DuckDB can aggregate them.  TRY_CAST on actual numeric types is a no-op.
        if self.name.upper() in ("SUM", "AVG", "STDDEV_SAMP", "STDDEV_POP", "VAR_SAMP", "VAR_POP") and len(self.args) == 1:
            arg = self.args[0]
            if not (isinstance(arg, SQLCast) and arg.target_type == "DOUBLE"):
                return SQLFunctionCall(
                    name=self.name,
                    args=[SQLCast(expression=arg, target_type="DOUBLE", try_cast=True)],
                    distinct=self.distinct,
                )

        # DuckDB list_sum/list_avg require numeric element types. Duration and
        # difference helpers now return scalar-or-interval VARCHAR, so cast list
        # elements at the list boundary for scalar aggregate use.
        if self.name.lower() in ("list_sum", "list_avg") and len(self.args) == 1:
            arg = self.args[0]
            already_cast = (
                isinstance(arg, SQLFunctionCall)
                and arg.name.lower() == "list_transform"
                and len(arg.args) >= 2
                and isinstance(arg.args[1], SQLLambda)
                and isinstance(arg.args[1].body, SQLCast)
                and arg.args[1].body.target_type == "DOUBLE"
            )
            if not already_cast:
                return SQLFunctionCall(
                    name=self.name,
                    args=[
                        SQLFunctionCall(
                            name="list_transform",
                            args=[
                                arg,
                                SQLLambda(
                                    param="_v",
                                    body=SQLCast(
                                        expression=SQLIdentifier(name="_v"),
                                        target_type="DOUBLE",
                                        try_cast=True,
                                    ),
                                ),
                            ],
                        )
                    ],
                )

        # intervalFromBounds: cast first two args to VARCHAR
        if self.name == "intervalFromBounds":
            arg_sqls: list[str] = []
            for i, arg in enumerate(self.args):
                arg_sql = arg.to_sql()
                if i < 2:
                    needs_cast = True
                    if isinstance(arg, SQLLiteral) and isinstance(arg.value, str):
                        needs_cast = False
                    elif isinstance(arg, SQLFunctionCall) and arg.name and arg.name.lower() in ('fhirpath_text', 'coalesce'):
                        needs_cast = False
                    elif isinstance(arg, SQLLiteral) and arg.value is None:
                        needs_cast = False
                    if needs_cast:
                        arg_sql = f"CAST({arg_sql} AS VARCHAR)"
                arg_sqls.append(arg_sql)
            return SQLRaw(f"{self.name}({', '.join(arg_sqls)})")

        return self

    def to_sql(self, parent_precedence: int = 0) -> str:
        # Apply pre-serialization normalization
        normalized = self.normalize()
        if normalized is not self:
            return normalized.to_sql(parent_precedence)

        if not self.args:
            return f"{self.name}()"

        # Build argument SQL, wrapping subqueries/selects/unions in parentheses
        arg_sqls = []
        for arg in self.args:
            arg_sql = arg.to_sql()
            # Wrap SQLSelect, SQLSubquery, or set operations in parentheses when used as function argument
            if isinstance(arg, SQLSelect):
                # SQLSelect needs wrapping
                arg_sql = f"({arg_sql})"
            elif isinstance(arg, (SQLIntersect, SQLExcept)):
                # INTERSECT/EXCEPT with parenthesized operands can't be used
                # directly as a scalar subquery.  Wrap as a scalar selecting
                # only the resource column (operands have patient_id, resource).
                arg_sql = f"(SELECT resource FROM ({arg_sql}) _setop)"
            elif isinstance(arg, SQLUnion):
                # Set operations in scalar context need parentheses
                arg_sql = f"({arg_sql})"
            # SQLSubquery.to_sql() already returns (SELECT...), so use as-is
            arg_sqls.append(arg_sql)

        if self.distinct:
            return f"{self.name}(DISTINCT {', '.join(arg_sqls)})"

        if self.order_by:
            order_parts = []
            for expr, direction in self.order_by:
                order_parts.append(f"{expr.to_sql()} {direction}")
            return f"{self.name}({', '.join(arg_sqls)} ORDER BY {', '.join(order_parts)})"

        return f"{self.name}({', '.join(arg_sqls)})"



@dataclass
class SQLBinaryOp(SQLExpression):
    """
    Represents a binary operator expression in SQL.

    Examples:
        a + b
        x = y
        name LIKE '%smith%'
    """

    operator: str
    left: SQLExpression
    right: SQLExpression
    precedence: int = 5  # Default to multiplicative

    # SQL comparison operators that DuckDB treats as non-associative —
    # `1 = 1 = TRUE` is a syntax error in DuckDB. When a SQLBinaryOp with
    # one of these operators appears as a child of another same-precedence
    # SQLBinaryOp, the child must be parenthesized. Surfaced by CQL-09
    # EXPLORER QA-003 (chained CQL equality `((1=1)=true)=((2=2)=true)`
    # emitted unparenthesized SQL `1 = 1 = TRUE = 2 = 2 = TRUE`).
    _NON_ASSOCIATIVE_OPS = frozenset({
        "=", "!=", "<>", "<", "<=", ">", ">=", "LIKE", "NOT LIKE", "IN", "NOT IN",
    })

    def __post_init__(self):
        # Set precedence based on operator
        op_upper = self.operator.upper()
        if op_upper in PRECEDENCE:
            self.precedence = PRECEDENCE[op_upper]

    def _child_parent_precedence(self) -> int:
        """Precedence value to pass to children when recursing in to_sql().

        For non-associative operators (DuckDB comparison ops), children at
        the same precedence must be parenthesized — achieved by passing
        `self.precedence + 1` so the child's `needs_parentheses` check
        (`self.precedence < parent_precedence`) returns True.
        """
        if self.operator.upper() in self._NON_ASSOCIATIVE_OPS:
            return self.precedence + 1
        return self.precedence

    def to_sql(self, parent_precedence: int = 0) -> str:
        child_parent_prec = self._child_parent_precedence()
        left_sql = self.left.to_sql(child_parent_prec)

        # Handle BETWEEN specially - right side should be "low AND high"
        if self.operator.upper() == "BETWEEN":
            # If right is a __between_args__ function, expand it
            if isinstance(self.right, SQLFunctionCall) and self.right.name == "__between_args__":
                if len(self.right.args) >= 2:
                    low_sql = self.right.args[0].to_sql(child_parent_prec)
                    high_sql = self.right.args[1].to_sql(child_parent_prec)
                    result = f"{left_sql} BETWEEN {low_sql} AND {high_sql}"
                    if self.needs_parentheses(parent_precedence):
                        return f"({result})"
                    return result
            # Otherwise, use the standard format
            right_sql = self.right.to_sql(child_parent_prec)
            result = f"{left_sql} BETWEEN {right_sql}"
            if self.needs_parentheses(parent_precedence):
                return f"({result})"
            return result

        right_sql = self.right.to_sql(child_parent_prec)

        result = f"{left_sql} {self.operator} {right_sql}"

        if self.needs_parentheses(parent_precedence):
            return f"({result})"

        return result


@dataclass
class SQLUnaryOp(SQLExpression):
    """
    Represents a unary operator expression in SQL.

    Examples:
        NOT x
        -5
        IS NULL
    """

    operator: str
    operand: SQLExpression
    prefix: bool = True  # True for NOT x, False for x IS NULL
    precedence: int = 3  # Default to NOT

    def __post_init__(self):
        # Set precedence based on operator
        op_upper = self.operator.upper()
        if op_upper == "NOT":
            self.precedence = PRECEDENCE["NOT"]
        elif op_upper == "-":
            self.precedence = PRECEDENCE["UNARY_MINUS"]
        elif op_upper == "+":
            self.precedence = PRECEDENCE["UNARY_PLUS"]

    def to_sql(self, parent_precedence: int = 0) -> str:
        operand_sql = self.operand.to_sql(self.precedence)

        if self.prefix:
            result = f"{self.operator} {operand_sql}"
        else:
            result = f"{operand_sql} {self.operator}"

        if self.needs_parentheses(parent_precedence):
            return f"({result})"

        return result


@dataclass
class SQLStructFieldAccess(SQLExpression):
    """Access a named field on a struct expression.

    Serializes as: (expr).field_name

    Used primarily to extract the boolean ``.result`` field from audit-macro
    structs (``audit_and``, ``audit_not``, ``audit_leaf``) when those
    expressions must be used as SQL WHERE / CASE WHEN predicates.
    """

    expr: SQLExpression
    field_name: str
    precedence: int = PRECEDENCE["PRIMARY"]

    def to_sql(self, parent_precedence: int = 0) -> str:
        return f"struct_extract({self.expr.to_sql()}, '{self.field_name}')"


@dataclass
class SQLCase(SQLExpression):
    """
    Represents a CASE expression in SQL.

    Examples:
        CASE WHEN x = 1 THEN 'one' ELSE 'other' END
        CASE x WHEN 1 THEN 'one' ELSE 'other' END
    """

    when_clauses: List[tuple] = field(default_factory=list)  # List of (condition, result)
    else_clause: Optional[SQLExpression] = None
    operand: Optional[SQLExpression] = None  # For simple CASE
    precedence: int = PRECEDENCE["PRIMARY"]

    def to_sql(self, parent_precedence: int = 0) -> str:
        parts = ["CASE"]

        if self.operand:
            # Simple CASE expression
            parts.append(self.operand.to_sql())

        for condition, result in self.when_clauses:
            result_sql = result.to_sql()
            # Set operations (INTERSECT/EXCEPT) in THEN position are parsed
            # as applying to the CASE result, not as the THEN value.
            # Wrap them in a scalar subquery to disambiguate.
            if isinstance(result, (SQLIntersect, SQLExcept)):
                result_sql = f"(SELECT resource FROM ({result_sql}) _setop)"
            if self.operand:
                parts.append(f"WHEN {condition.to_sql()} THEN {result_sql}")
            else:
                parts.append(f"WHEN {condition.to_sql()} THEN {result_sql}")

        if self.else_clause:
            else_sql = self.else_clause.to_sql()
            if isinstance(self.else_clause, (SQLIntersect, SQLExcept)):
                else_sql = f"(SELECT resource FROM ({else_sql}) _setop)"
            parts.append(f"ELSE {else_sql}")

        parts.append("END")

        result = " ".join(parts)

        if self.needs_parentheses(parent_precedence):
            return f"({result})"

        return result


@dataclass
class SQLArray(SQLExpression):
    """
    Represents an ARRAY constructor in SQL (DuckDB syntax).

    Examples:
        [1, 2, 3]
        ['a', 'b', 'c']
    """

    elements: List[SQLExpression] = field(default_factory=list)
    precedence: int = PRECEDENCE["PRIMARY"]

    def to_sql(self, parent_precedence: int = 0) -> str:
        if not self.elements:
            return "[]"

        elem_sqls = [elem.to_sql() for elem in self.elements]
        return f"[{', '.join(elem_sqls)}]"


@dataclass
class SQLList(SQLExpression):
    """
    Represents a list literal (tuple) in SQL.

    Used for IN clauses and list operations.

    Examples:
        ('confirmed', 'provisional')
        (1, 2, 3)
    """

    items: List[SQLExpression] = field(default_factory=list)
    precedence: int = PRECEDENCE["PRIMARY"]

    def to_sql(self, parent_precedence: int = 0) -> str:
        if not self.items:
            return "()"

        items_sql = ", ".join(item.to_sql() for item in self.items)
        return f"({items_sql})"


# CQL list macros whose DuckDB expansions contain subqueries (e.g.
# CQLListDistinctEq's (SELECT list(...) FROM unnest ...)). DuckDB forbids
# subqueries inside lambda bodies, so these must never render there.
# Distinct has a lambda-safe twin for primitive-element lists: DuckDB's
# list_distinct (order-insensitive, null-dropping — acceptable inside
# lambda bodies where SDE tuple-building consumes code lists; the
# order-preserving macro remains correct everywhere else).
_LAMBDA_UNSAFE_MACROS = frozenset({'"Distinct"'})


def _rewrite_distinct_calls(text: str) -> str:
    """Recursively rewrite `"Distinct"(...)` → `list_distinct(...)` in a
    rendered argument string (nested calls inside lambda bodies)."""
    m = re.search(r'"Distinct"\s*\(', text)
    if not m:
        return text
    start = m.start()
    depth = 1
    j = m.end()
    while depth > 0 and j < len(text):
        c = text[j]
        if c == "(":
            depth += 1
        elif c == ")":
            depth -= 1
        j += 1
    if depth != 0:
        raise TranslationError(
            "Unbalanced parentheses while rewriting nested Distinct."
        )
    call = text[start:j]
    if "(SELECT" in call.upper():
        raise TranslationError(
            "Distinct over a subquery cannot be used inside a list lambda "
            "(DuckDB forbids subqueries in lambda bodies)."
        )
    arg = _rewrite_distinct_calls(call[m.end():])
    return text[:start] + "list_distinct(" + arg + text[j:]


def _render_lambda_body(body: SQLExpression) -> str:
    """Render a lambda body, guarding against subquery-carrying macros.

    DuckDB raises an opaque Binder Error when a lambda body contains a
    subquery. The only reachable source is CQL list macros implemented
    via (SELECT ...). If one appears in the rendered body:

    - ``"Distinct"(<arg>)`` is rewritten to ``list_distinct(<arg>)`` —
      semantically valid for the primitive-element lists that reach
      lambda bodies (SDE code lists); CQL §10.2 order/null nuances are
      documented as outside the lambda-safe subset.
    - any other unsafe macro raises a typed error naming the construct,
      so the failure is actionable at translate time instead of an
      opaque bind failure at execution.
    """
    rendered = body.to_sql()
    for macro in _LAMBDA_UNSAFE_MACROS:
        if macro not in rendered:
            continue
        if macro == '"Distinct"':
            # Balanced scan: rewrite complete "Distinct"(...) calls whose
            # arguments contain no subqueries themselves; raise on any
            # subquery-carrying argument (not lambda-safe either way).
            # RECURSES on rewritten args so nested Distinct calls inside
            # the argument also become list_distinct.
            out: list[str] = []
            i = 0
            while True:
                m = re.search(r'"Distinct"\s*\(', rendered[i:])
                if not m:
                    out.append(rendered[i:])
                    break
                start = i + m.start()
                out.append(rendered[i:start])
                depth = 1
                j = i + m.end()  # m offsets are relative to rendered[i:]
                while depth > 0 and j < len(rendered):
                    c = rendered[j]
                    if c == "(":
                        depth += 1
                    elif c == ")":
                        depth -= 1
                    j += 1
                if depth != 0:
                    raise TranslationError(
                        "Unbalanced parentheses in lambda body while "
                        "rewriting Distinct (internal render invariant)."
                    )
                call = rendered[start:j]
                if "(SELECT" in call.upper():
                    raise TranslationError(
                        "Distinct over a subquery cannot be used inside a "
                        "list lambda (DuckDB forbids subqueries in lambda "
                        "bodies). Rewrite the CQL to hoist the Distinct "
                        "outside the iteration."
                    )
                # m is matched against rendered[i:]; m.end() - m.start()
                # is the macro+open-paren length within the SAME slice
                # coordinate as call's start.
                arg = call[m.end() - m.start():]
                arg = _rewrite_distinct_calls(arg)  # nested calls
                out.append("list_distinct(" + arg)
                i = j
            rendered = "".join(out)
        else:  # pragma: no cover - registry has one entry today
            raise TranslationError(
                f"{macro} cannot be used inside a list lambda body "
                "(subquery-carrying macro); hoist it outside the iteration."
            )
    return rendered


@dataclass
class SQLLambda(SQLExpression):
    """
    Represents a lambda expression for list operations in SQL.

    Used in list_filter, list_apply, etc.

    Examples:
        lambda r: r.status = 'completed'
        lambda x: fhirpath_text(x, 'code')

    Renders DuckDB's `lambda param:` syntax (accepted by DuckDB 1.5 AND
    2.0; the arrow `param ->` form is removed in 2.0 — D1 migration).
    """

    param: str
    body: SQLExpression
    precedence: int = PRECEDENCE["PRIMARY"]

    def to_sql(self, parent_precedence: int = 0) -> str:
        return f"lambda {self.param}: {_render_lambda_body(self.body)}"


@dataclass
class SQLLambda2(SQLExpression):
    """
    Represents a two-parameter lambda expression for list_reduce.

    Examples:
        lambda x, y: x + y
        lambda acc, elem: acc * elem
    """

    params: List[str]
    body: SQLExpression
    precedence: int = PRECEDENCE["PRIMARY"]

    def to_sql(self, parent_precedence: int = 0) -> str:
        return f"lambda {', '.join(self.params)}: {_render_lambda_body(self.body)}"


@dataclass
class SQLAlias(SQLExpression):
    """
    Represents an alias for an expression (expr AS alias).

    Examples:
        COUNT(*) AS total
        resource->>'id' AS patient_id
        resources r  (implicit_alias=True, for FROM clauses)
    """

    expr: SQLExpression
    alias: str
    implicit_alias: bool = False  # If True, render without AS keyword (for FROM clauses)
    precedence: int = PRECEDENCE["PRIMARY"]

    def to_sql(self, parent_precedence: int = 0) -> str:
        # Quote alias if it contains special characters or is a reserved word
        needs_quoting = (
            ' ' in self.alias or
            any(c in self.alias for c in '-()') or
            self.alias.upper() in _SQL_RESERVED_WORDS
        )
        keyword = "" if self.implicit_alias else " AS"
        expr_sql = self.expr.to_sql()
        # Wrap UNION/INTERSECT/EXCEPT in parens when used as FROM source
        if type(self.expr).__name__ in ('SQLUnion', 'SQLIntersect', 'SQLExcept'):
            expr_sql = f"({expr_sql})"
        # Wrap CASE in a subquery when used as FROM source with alias
        elif isinstance(self.expr, SQLCase):
            expr_sql = f"(SELECT {expr_sql})"
        if needs_quoting:
            escaped = self.alias.replace('"', '""')
            return f"{expr_sql}{keyword} \"{escaped}\""
        return f"{expr_sql}{keyword} {self.alias}"


@dataclass
class SQLInterval(SQLExpression):
    """
    Represents an interval literal or constructor in SQL.

    For DuckDB, we use a JSON representation for CQL intervals.
    """

    low: Optional[SQLExpression] = None
    high: Optional[SQLExpression] = None
    low_closed: bool = True
    high_closed: bool = True
    precedence: int = PRECEDENCE["PRIMARY"]

    def to_sql(self, parent_precedence: int = 0) -> str:
        # Build interval using intervalFromBounds UDF (expects VARCHAR inputs)
        low_sql = self.low.to_sql() if self.low else "NULL"
        high_sql = self.high.to_sql() if self.high else "NULL"
        low_closed_sql = "TRUE" if self.low_closed else "FALSE"
        high_closed_sql = "TRUE" if self.high_closed else "FALSE"

        # intervalFromBounds expects VARCHAR; wrap typed args (DATE, TIMESTAMP, etc.)
        # Always cast non-NULL, non-string-literal args to avoid type mismatches
        if self.low and not isinstance(self.low, SQLNull):
            if self.low.is_date_typed() or self._needs_varchar_cast(self.low):
                low_sql = f"CAST({low_sql} AS VARCHAR)"
        if self.high and not isinstance(self.high, SQLNull):
            if self.high.is_date_typed() or self._needs_varchar_cast(self.high):
                high_sql = f"CAST({high_sql} AS VARCHAR)"

        return f"intervalFromBounds({low_sql}, {high_sql}, {low_closed_sql}, {high_closed_sql})"

    @staticmethod
    def _needs_varchar_cast(expr: "SQLExpression") -> bool:
        """Check if an expression might produce a non-VARCHAR type that needs casting.

        intervalFromBounds requires VARCHAR inputs.  Rather than enumerating
        all non-VARCHAR producers, whitelist known VARCHAR forms and cast the rest.
        """
        # String literals are already VARCHAR
        if isinstance(expr, SQLLiteral) and isinstance(expr.value, str):
            return False
        # fhirpath_text / COALESCE of fhirpath_text already return VARCHAR
        if isinstance(expr, SQLFunctionCall) and expr.name and expr.name.lower() in (
            "fhirpath_text", "coalesce",
        ):
            return False
        # NULL is type-agnostic
        if isinstance(expr, SQLNull):
            return False
        # Everything else (subqueries, CAST, timestamps, qualified refs) needs casting
        return True


@dataclass
class SQLCast(SQLExpression):
    """
    Represents a CAST expression in SQL.

    Examples:
        CAST(x AS VARCHAR)
        TRY_CAST(value AS DOUBLE)
    """

    expression: SQLExpression
    target_type: str
    try_cast: bool = False
    precedence: int = PRECEDENCE["PRIMARY"]

    def to_sql(self, parent_precedence: int = 0) -> str:
        expr_sql = self.expression.to_sql()
        keyword = "TRY_CAST" if self.try_cast else "CAST"
        # CQL temporal values are now VARCHAR ISO 8601 strings.
        # DATE casts previously served two purposes: (1) type assertion and
        # (2) day-level truncation (stripping time component).  We preserve
        # both by emitting LEFT(CAST(x AS VARCHAR), 10) which yields a
        # 'YYYY-MM-DD' VARCHAR — safe in COALESCE and comparison contexts.
        if self.target_type == "DATE":
            return f"LEFT({keyword}({expr_sql} AS VARCHAR), 10)"
        return f"{keyword}({expr_sql} AS {self.target_type})"

    def is_date_typed(self) -> bool:
        """Check if this CAST targets DATE type."""
        return self.target_type == "DATE"


@dataclass
class SQLJoin(SQLExpression):
    """
    Represents a JOIN clause in SQL.

    Examples:
        LEFT JOIN resources r ON r.patient_ref = p.patient_id
        INNER JOIN conditions c ON c.subject = p.id
    """

    join_type: str  # "LEFT", "INNER", "RIGHT", "CROSS"
    table: SQLExpression  # Table name or subquery
    alias: Optional[str] = None
    on_condition: Optional[SQLExpression] = None
    precedence: int = PRECEDENCE["PRIMARY"]

    def to_sql(self, parent_precedence: int = 0) -> str:
        jt = self.join_type.upper()
        # If join_type already contains "JOIN" (e.g. "CROSS JOIN LATERAL"), don't append "JOIN"
        parts = [jt] if "JOIN" in jt else [jt, "JOIN"]

        # Table reference
        table_sql = self.table.to_sql()
        if isinstance(self.table, SQLSelect):
            # Wrap subqueries in parentheses
            if not table_sql.startswith('('):
                table_sql = f"({table_sql})"

        if self.alias:
            parts.append(f"{table_sql} AS {self.alias}")
        else:
            parts.append(table_sql)

        # ON condition
        if self.on_condition:
            parts.append(f"ON {self.on_condition.to_sql()}")

        return " ".join(parts)


@dataclass
class SQLSelect(SQLExpression):
    """
    Represents a SELECT statement.

    Attributes:
        columns: List of column expressions (can be SQLExpression or (SQLExpression, alias) tuple)
        from_clause: The FROM clause (table name or subquery)
        joins: Optional list of JOIN clauses
        where: Optional WHERE clause expression
        group_by: Optional GROUP BY columns
        having: Optional HAVING clause
        order_by: Optional ORDER BY columns
        limit: Optional LIMIT value
    """

    columns: List[Union[SQLExpression, tuple]] = field(default_factory=list)
    from_clause: Optional[SQLExpression] = None
    joins: List["SQLJoin"] = field(default_factory=list)
    where: Optional[SQLExpression] = None
    group_by: Optional[List[SQLExpression]] = None
    having: Optional[SQLExpression] = None
    order_by: Optional[List[tuple]] = None  # List of (expr, 'ASC'|'DESC')
    limit: Optional[int] = None
    distinct: bool = False
    # DuckDB DISTINCT ON (expr, ...) — collapses to the first row per
    # distinct-on key. Used by _patients with demographics to guarantee
    # ONE row per patient id even when duplicate Patient rows exist (the
    # loader sanctions same-(id, resourceType) rows; review finding 1.1).
    distinct_on: Optional[List[SQLExpression]] = None
    precedence: int = PRECEDENCE["PRIMARY"]

    def to_sql(self, parent_precedence: int = 0) -> str:
        parts = ["SELECT"]

        if self.distinct_on:
            on_parts = [e.to_sql() for e in self.distinct_on]
            parts.append(f"DISTINCT ON ({', '.join(on_parts)})")
        elif self.distinct:
            parts.append("DISTINCT")

        # Columns
        if not self.columns:
            parts.append("*")
        else:
            col_parts = []
            for col in self.columns:
                if isinstance(col, tuple):
                    expr, alias = col
                    # Quote alias to handle reserved words like NULL, TRUE, FALSE
                    quoted_alias = f'"{alias}"' if alias.upper() in (
                        "NULL", "TRUE", "FALSE", "SELECT", "FROM", "WHERE",
                        "AND", "OR", "NOT", "IN", "IS", "LIKE", "BETWEEN",
                        "EXISTS", "CASE", "WHEN", "THEN", "ELSE", "END",
                        "JOIN", "LEFT", "RIGHT", "INNER", "OUTER", "ON",
                        "GROUP", "BY", "HAVING", "ORDER", "ASC", "DESC",
                        "LIMIT", "OFFSET", "UNION", "INTERSECT", "EXCEPT",
                        "DISTINCT", "ALL", "AS", "WITH", "RECURSIVE"
                    ) else alias
                    col_parts.append(f"{expr.to_sql()} AS {quoted_alias}")
                else:
                    col_parts.append(col.to_sql())
            parts.append(", ".join(col_parts))

        # FROM
        if self.from_clause:
            from_sql = self.from_clause.to_sql()
            # Wrap in parentheses if it's a subquery (SELECT) that isn't already parenthesized
            if isinstance(self.from_clause, SQLSelect):
                if not from_sql.startswith('('):
                    from_sql = f"({from_sql})"
            # Wrap SQLUnion in parentheses with alias when used as FROM source
            elif isinstance(self.from_clause, SQLUnion):
                from_sql = f"({from_sql}) AS _union"
            # Wrap SQLCase in a subquery — CASE cannot be a direct FROM source
            elif isinstance(self.from_clause, SQLCase):
                from_sql = f"(SELECT {from_sql}) AS _case"
            parts.append(f"FROM {from_sql}")

        # JOINs
        if self.joins:
            for join in self.joins:
                parts.append(join.to_sql())

        # WHERE
        if self.where:
            parts.append(f"WHERE {self.where.to_sql()}")

        # GROUP BY
        if self.group_by:
            group_parts = [g.to_sql() for g in self.group_by]
            parts.append(f"GROUP BY {', '.join(group_parts)}")

        # HAVING
        if self.having:
            parts.append(f"HAVING {self.having.to_sql()}")

        # ORDER BY
        if self.order_by:
            order_parts = []
            for expr, direction in self.order_by:
                order_parts.append(f"{expr.to_sql()} {direction}")
            parts.append(f"ORDER BY {', '.join(order_parts)}")

        # LIMIT
        if self.limit is not None:
            parts.append(f"LIMIT {self.limit}")

        return " ".join(parts)



@dataclass
class SQLSubquery(SQLExpression):
    """
    Represents a subquery in SQL.

    Used for EXISTS, IN subqueries, scalar subqueries, etc.
    """

    query: SQLSelect
    precedence: int = PRECEDENCE["PRIMARY"]

    def to_sql(self, parent_precedence: int = 0) -> str:
        return f"({self.query.to_sql()})"


@dataclass
class SQLRecursiveCTEFold(SQLExpression):
    """
    Represents a recursive CTE fold over a list expression.

    Used for CQL Aggregate clauses with list-typed accumulators where
    list_reduce cannot handle the type mismatch between the accumulator
    (array) and the source elements (scalars).

    Generates SQL of the form:
        (WITH RECURSIVE __src AS (
            SELECT ROW_NUMBER() OVER () AS __rn,
                   CAST(elem AS VARCHAR) AS elem
            FROM (SELECT [DISTINCT] UNNEST(source) AS elem)
        ), __fold AS (
            SELECT anchor AS __acc, CAST(0 AS BIGINT) AS __rn
            UNION ALL
            SELECT body, __src.__rn
            FROM __fold JOIN __src ON __src.__rn = __fold.__rn + 1
        ) SELECT __acc FROM __fold ORDER BY __rn DESC LIMIT 1)
    """

    source_expr: SQLExpression
    source_alias: str
    anchor: SQLExpression
    body: SQLExpression
    distinct: bool = False
    accum_alias: str = "__acc"
    precedence: int = PRECEDENCE["PRIMARY"]

    def to_sql(self, parent_precedence: int = 0) -> str:
        src = self.source_expr.to_sql()
        body_sql = self.body.to_sql()
        anchor_sql = self.anchor.to_sql()
        distinct_kw = "DISTINCT " if self.distinct else ""
        a = self.source_alias
        acc = self.accum_alias
        return (
            f"(WITH RECURSIVE __src AS ("
            f"SELECT ROW_NUMBER() OVER () AS __rn, "
            f"CAST({a} AS VARCHAR) AS {a} "
            f"FROM (SELECT {distinct_kw}UNNEST({src}) AS {a})"
            f"), __fold AS ("
            f"SELECT {anchor_sql} AS {acc}, CAST(0 AS BIGINT) AS __rn "
            f"UNION ALL "
            f"SELECT {body_sql}, __src.__rn "
            f"FROM __fold JOIN __src ON __src.__rn = __fold.__rn + 1"
            f") SELECT {acc} FROM __fold ORDER BY __rn DESC LIMIT 1)"
        )


@dataclass
class SQLExists(SQLExpression):
    """
    Represents an EXISTS expression.

    Examples:
        EXISTS (SELECT 1 FROM t WHERE ...)
    """

    subquery: SQLSubquery
    precedence: int = PRECEDENCE["PRIMARY"]

    def to_sql(self, parent_precedence: int = 0) -> str:
        return f"EXISTS {self.subquery.to_sql()}"


@dataclass
class CTEDefinition:
    """
    Represents a Common Table Expression (CTE) definition.

    CTEs are used to build up complex queries with named subqueries.
    """

    name: str
    query: SQLSelect
    columns: Optional[List[str]] = None  # Optional column aliases
    # PERF retrieve-cache / phase2 item 3: emit AS MATERIALIZED so DuckDB
    # does not inline the CTE into consumers and push heavy definition
    # predicates into the base table scans (CMS130 rung5k: 2,178s + 506s +
    # 471s SEQ_SCANs). ``True`` forces MATERIALIZED; ``False`` forces plain;
    # ``None`` (default) means AUTO: the emission pass resolves it by
    # reference count — CTEs referenced by more than one consumer keep
    # MATERIALIZED (re-inlining a multi-ref CTE duplicates the scan and is
    # what re-created the pathology), single-reference CTEs drop it
    # (inlining once is equal-or-faster and avoids eager materialization
    # cost; measured CMS2 rung100 2046->1910ms, CMS130 rung1000
    # 12801->11658ms, parity row-identical).
    materialized: Optional[bool] = None

    def to_sql(self) -> str:
        query_sql = self.query.to_sql()
        mat = "MATERIALIZED " if self.materialized is True else ""
        if self.columns:
            cols = f"({', '.join(self.columns)})"
            return f"{self.name}{cols} AS {mat}(\n{query_sql}\n)"
        return f"{self.name} AS {mat}(\n{query_sql}\n)"


def _build_precomputed_column_expression(col_def: ColumnDefinition) -> SQLAlias:
    path_exprs = [
        SQLFunctionCall(
            name=col_def.fhirpath_function,
            args=[
                SQLQualifiedIdentifier(parts=["r", "resource"]),
                SQLLiteral(value=path),
            ],
        )
        for path in col_def.paths
    ]
    expr = path_exprs[0] if len(path_exprs) == 1 else SQLFunctionCall(name="COALESCE", args=path_exprs)
    return SQLAlias(expr=expr, alias=col_def.column_name)


@dataclass
class SQLRetrieveCTE:
    """
    Represents a CTE for a FHIR resource retrieval with ValueSet filter.

    This is used to generate optimized CTEs that pre-compute commonly used
    columns and can be referenced multiple times in a query.

    Example output:
        "Condition: Essential Hypertension" AS MATERIALIZED (
            SELECT
                r.patient_ref,
                r.resource,
                COALESCE(...) AS effective_date
            FROM resources r
            WHERE r.resourceType = 'Condition'
              AND in_valueset(r.resource, 'code', 'http://...')
        )
    """

    name: str                          # CTE name: "{resourceType}: {valueset_alias}"
    resource_type: str                 # FHIR resource type (e.g., "Condition", "Observation")
    valueset_url: Optional[str] = None           # ValueSet URL for code filtering
    valueset_alias: Optional[str] = None         # Short alias from CQL (e.g., "Essential Hypertension")
    profile_url: Optional[str] = None            # Optional US-Core/QICore profile URL
    precomputed_columns: Dict[str, SQLExpression] = field(default_factory=dict)  # column_name -> SQL expression
    materialized: bool = True          # Use MATERIALIZED hint for DuckDB optimization

    # Choice-type columns that may contain different types
    _CHOICE_TYPE_COLUMN_NAMES: set = field(default_factory=lambda: {"value", "onset", "effective"})

    def get_column_info(self) -> Dict[str, "ColumnInfo"]:
        """
        Get ColumnInfo for all precomputed columns.

        Returns:
            Dict mapping column_name -> ColumnInfo for each precomputed column.
        """
        from ..translator.column_registry import ColumnInfo

        result = {}
        for col_name, col_expr in self.precomputed_columns.items():
            fhirpath = self._extract_fhirpath(col_expr)
            result[col_name] = ColumnInfo(
                column_name=col_name,
                fhirpath=fhirpath,
                sql_type=self._infer_sql_type(col_expr),
                is_choice_type=self._is_choice_type_column(col_name),
            )
        return result

    def _extract_fhirpath(self, col_expr: SQLExpression) -> str:
        """
        Extract FHIRPath expression from column definition.

        Parses fhirpath_text(r.resource, 'path') -> 'path'
        Handles COALESCE of multiple fhirpath calls.
        """
        from ..translator import ast_utils
        
        # Use AST-based extraction instead of regex on SQL string
        fhirpath = ast_utils.extract_fhirpath_from_ast(col_expr)
        if fhirpath:
            # For COALESCE, returns comma-separated paths - take first
            if ',' in fhirpath:
                return fhirpath.split(',')[0].strip()
            return fhirpath
        
        return ""

    def _infer_sql_type(self, col_expr: SQLExpression) -> str:
        """
        Infer SQL type from expression.

        Looks at the fhirpath function name to determine the return type.
        """
        from ..translator import ast_utils
        
        # Use AST-based type inference instead of string matching
        return ast_utils.infer_sql_type_from_ast(col_expr)

    def _is_choice_type_column(self, col_name: str) -> bool:
        """
        Check if a column is a choice-type column.

        Choice-type columns may contain different types depending on
        which FHIR path is populated.
        """
        # Check if the column name matches known choice-type patterns
        col_lower = col_name.lower()
        for choice_type in self._CHOICE_TYPE_COLUMN_NAMES:
            if col_lower.startswith(choice_type) or col_lower == choice_type:
                return True
        return False

    @classmethod
    def create_with_precomputed_columns(
        cls,
        resource_type: str,
        valueset_url: str | None = None,
        valueset_alias: str | None = None,
        profile_url: str | None = None,
        name: str | None = None,
        fhir_schema: Optional["FHIRSchemaRegistry"] = None,
        profile_registry: Optional["ProfileRegistry"] = None,
        column_mappings: Optional[Dict[str, str]] = None,
        choice_type_prefixes: Optional[set] = None,
    ) -> "SQLRetrieveCTE":
        """
        Create a SQLRetrieveCTE with automatically populated pre-computed columns.

        Args:
            resource_type: FHIR resource type
            valueset_url: Optional ValueSet URL
            valueset_alias: Short alias from CQL
            profile_url: Optional profile URL
            name: Optional CTE name (auto-generated if not provided)

        Returns:
            SQLRetrieveCTE with pre-computed columns for the resource type
        """
        # Generate name if not provided
        if name is None:
            if valueset_alias:
                name = f"{resource_type}: {valueset_alias}"
            else:
                name = resource_type

        property_paths = get_default_property_paths(
            resource_type, profile_url,
            fhir_schema=fhir_schema, profile_registry=profile_registry,
        )
        column_defs = build_column_definitions(
            resource_type, property_paths, fhir_schema=fhir_schema,
            column_mappings=column_mappings, choice_type_prefixes=choice_type_prefixes,
        )

        precomputed = {}
        for col_name in sorted(column_defs):
            precomputed[col_name] = _build_precomputed_column_expression(column_defs[col_name])

        return cls(
            name=name,
            resource_type=resource_type,
            valueset_url=valueset_url,
            valueset_alias=valueset_alias,
            profile_url=profile_url,
            precomputed_columns=precomputed,
        )

    def to_sql(self) -> str:
        """Generate the CTE SQL clause."""
        # Build column list - alias patient_ref AS patient_id for consistent JOIN conditions
        columns: List[SQLExpression] = [
            SQLAlias(
                expr=SQLQualifiedIdentifier(parts=["r", "patient_ref"]),
                alias="patient_id"
            ),
            SQLQualifiedIdentifier(parts=["r", "resource"]),
        ]

        # Add precomputed columns (already aliased)
        for col_name, col_expr in self.precomputed_columns.items():
            columns.append(col_expr)  # col_expr is already an SQLAlias

        # Build WHERE conditions
        conditions: List[SQLExpression] = [
            SQLBinaryOp(
                operator="=",
                left=SQLQualifiedIdentifier(parts=["r", "resourceType"]),
                right=SQLLiteral(value=self.resource_type),
            )
        ]

        # Add valueset filter if present
        if self.valueset_url:
            from ..translator.types import SQLFunctionCall
            from ..translator.patterns.retrieve import _TERMINOLOGY_PROPERTY_DEFAULTS
            effective_code_property = _TERMINOLOGY_PROPERTY_DEFAULTS.get(self.resource_type, "code")
            if self.valueset_url.startswith("urn:cql:code:"):
                # Direct code reference: urn:cql:code:<system>|<code>
                parts = self.valueset_url[len("urn:cql:code:"):].split("|", 1)
                system_url = parts[0] if len(parts) > 0 else ""
                code_val = parts[1] if len(parts) > 1 else ""
                escaped_system = escape_fhirpath_string_literal(system_url)
                escaped_code = escape_fhirpath_string_literal(code_val)
                fhirpath_expr = f"{effective_code_property}.coding.where(system='{escaped_system}' and code='{escaped_code}').exists()"
                valueset_filter = SQLFunctionCall(
                    name="fhirpath_bool",
                    args=[
                        SQLQualifiedIdentifier(parts=["r", "resource"]),
                        SQLLiteral(value=fhirpath_expr),
                    ],
                )
            else:
                valueset_filter = SQLFunctionCall(
                    name="in_valueset",
                    args=[
                        SQLQualifiedIdentifier(parts=["r", "resource"]),
                        SQLLiteral(value=effective_code_property),
                        SQLLiteral(value=self.valueset_url),
                    ],
                )
            conditions.append(valueset_filter)

        # Combine conditions with AND
        where_clause: Optional[SQLExpression] = None
        if len(conditions) == 1:
            where_clause = conditions[0]
        elif len(conditions) > 1:
            # Build AND chain
            where_clause = conditions[0]
            for cond in conditions[1:]:
                where_clause = SQLBinaryOp(
                    operator="AND",
                    left=where_clause,
                    right=cond,
                )

        # Build SELECT
        select = SQLSelect(
            columns=columns,
            from_clause=SQLAlias(expr=SQLIdentifier(name="resources"), alias="r", implicit_alias=True),
            where=where_clause,
            distinct=True,
        )

        # Generate CTE clause
        mat_hint = "MATERIALIZED " if self.materialized is True else ""
        # Quote the CTE name to handle colons and spaces
        quoted_name = f'"{self.name}"' if ':' in self.name or ' ' in self.name else self.name
        return f'{quoted_name} AS {mat_hint}({select.to_sql()})'

def deduplicate_retrieve_ctes(ctes: List[SQLRetrieveCTE]) -> List[SQLRetrieveCTE]:
    """
    Deduplicate CTEs by (resource_type, valueset_url).

    When the same valueset is used multiple times for the same resource type,
    only keep one CTE to avoid redundant computation.

    Args:
        ctes: List of SQLRetrieveCTE objects to deduplicate.

    Returns:
        Deduplicated list of SQLRetrieveCTE objects.
    """
    seen: Dict[tuple, SQLRetrieveCTE] = {}
    for cte in ctes:
        key = (cte.resource_type, cte.valueset_url)
        if key not in seen:
            seen[key] = cte
    return list(seen.values())


def _mask_quoted_sql(sql: str) -> str:
    """Blank out the CONTENTS of string literals and quoted identifiers.

    Used by :meth:`SQLFragment._resolve_materialization` to measure paren
    depth at CTE-name occurrence positions without being skewed by
    parentheses inside literals (valueset names like ``"... (encounter-
    diagnosis)"`` carry their own parens). Quotes themselves are preserved
    and the output has the same length as the input, so occurrence indices
    computed on the original SQL remain valid.
    """
    out = list(sql)
    i = 0
    n = len(sql)
    while i < n:
        ch = sql[i]
        if ch == "'":
            j = i + 1
            while j < n:
                if sql[j] == "'":
                    if j + 1 < n and sql[j + 1] == "'":  # escaped ''
                        j += 2
                        continue
                    break
                j += 1
            for k in range(i + 1, min(j, n)):
                out[k] = " "
            i = j + 1 if j < n else n
        elif ch == '"':
            j = sql.find('"', i + 1)
            end = j if j != -1 else n
            for k in range(i + 1, end):
                out[k] = " "
            i = end + 1 if j != -1 else n
        else:
            i += 1
    return "".join(out)


@dataclass
class SQLFragment:
    """
    A container for a complete SQL fragment with CTEs.

    Represents a complete SQL statement with optional CTEs (WITH clause).
    """

    main_query: SQLSelect
    ctes: List[CTEDefinition] = field(default_factory=list)

    def _resolve_materialization(self) -> None:
        """PERF phase2 item 3: resolve AUTO (``materialized is None``) CTEs
        by reference count. A CTE referenced by MORE THAN ONE consumer keeps
        ``AS MATERIALIZED`` (re-inlining a multi-ref CTE duplicates its scan
        and lets DuckDB push heavy consumer predicates into the base table —
        the exact pathology MATERIALIZED fencing fixed). A CTE referenced at
        most once drops MATERIALIZED (inlining once is equal-or-faster and
        avoids eager materialization cost).

        A single-reference CTE ALSO keeps MATERIALIZED when its one
        reference is NESTED (inside a subquery — e.g. an arm of a UNION
        chain inside a correlated EXISTS) rather than a top-level FROM
        table of its consumer. Inlining into a nested context lets DuckDB
        re-evaluate the CTE body per outer row / lose the join-order fence,
        which is the CMS133 regression (sql_execution 732ms -> ~2000ms,
        traced to one Condition retrieve whose only reference sat at
        paren-depth 2 inside ``WHERE EXISTS (SELECT 1 FROM (... UNION
        ...) AS X WHERE ... AND X.patient_id = outer.patient_id)``;
        materializing just that one CTE restored ~170ms).

        Reference counting is lexical on rendered SQL: each CTE's name is
        counted inside every OTHER CTE's rendered body plus the main query.
        Nesting is measured as the paren depth at the occurrence position,
        computed on a quote-masked copy of the consumer SQL so parens
        inside string literals / quoted identifiers (valueset names carry
        them) do not skew the count.

        NOTE: resolves by MUTATING the CTEDefinitions in place; assumes
        to_sql() is called once per fragment (every translator path does —
        a second call would reuse stale resolutions via the is-not-None
        guard).
        """
        if not any(cte.materialized is None for cte in self.ctes):
            return
        rendered = {
            cte.name: cte.query.to_sql()
            for cte in self.ctes
        }
        main_sql = self.main_query.to_sql()
        masked = {
            cte.name: _mask_quoted_sql(cte.query.to_sql())
            for cte in self.ctes
        }
        masked_main = _mask_quoted_sql(main_sql)

        def _nested_reference(name: str, consumer: str, consumer_masked: str) -> bool:
            """True if ``name`` occurs at paren depth > 0 in the consumer.

            Occurrence positions are found in the rendered SQL (the mask
            blanks quoted-identifier contents, so quoted CTE names would
            never match there); depth is measured on the masked copy.
            """
            idx = consumer.find(name)
            while idx != -1:
                prefix = consumer_masked[:idx]
                if prefix.count("(") - prefix.count(")") > 0:
                    return True
                idx = consumer.find(name, idx + len(name))
            return False

        for cte in self.ctes:
            if cte.materialized is not None:
                continue
            refs = 0
            nested = False
            name = cte.name
            for other in self.ctes:
                if other.name == name:
                    continue
                refs += rendered[other.name].count(name)
                if _nested_reference(name, rendered[other.name], masked[other.name]):
                    nested = True
            refs += main_sql.count(name)
            if _nested_reference(name, main_sql, masked_main):
                nested = True
            cte.materialized = refs > 1 or nested

    def to_sql(self) -> str:
        if not self.ctes:
            return self.main_query.to_sql()

        self._resolve_materialization()
        cte_parts = [cte.to_sql() for cte in self.ctes]
        with_clause = "WITH " + ",\n".join(cte_parts)
        return f"{with_clause}\n{self.main_query.to_sql()}"



    def rewrite_promotion_lookups_as_joins(self) -> None:
        """AMUX-126: rewrite promotion-lookup correlated scalar subqueries as LEFT JOINs.

        The promotion machinery emits per-call lookups of the shape
            (SELECT value FROM "<fn-cte>" AS _fv
             WHERE _fv.patient_id = <src>.patient_id
               AND _fv._row_key = <key-expr over <src>>)
        DuckDB 2.0's planner scales EXPONENTIALLY in the number of such
        correlated subqueries (duckdb/duckdb#28842); LEFT JOINs plan
        linearly. This pass, run after lateral dedup, finds every such
        subquery whose source alias is bound at the same SELECT scope,
        adds one deduplicated LEFT JOIN per (cte, source, key) triple,
        and replaces the subqueries with `_fvN.value` column references.
        Lookups in unreachable scopes (shadowed aliases) are left as-is.
        """
        import os as _os
        global _PJ_DEBUG
        _dbg = _os.environ.get("FHIR4DS_CQL_PROMOTION_JOINS_DEBUG") == "1"
        _PJ_DEBUG = _dbg
        _before = 0
        if _dbg:
            for cte in self.ctes:
                _before += _count_promotion_lookups_generic(cte.query)
            _before += _count_promotion_lookups_generic(self.main_query)
        _global_counter = [0]
        for cte in self.ctes:
            _promotions_rewrite_select(cte.query, _global_counter)
        _promotions_rewrite_select(self.main_query, _global_counter)
        _PJ_DEBUG = False
        if _dbg:
            import sys
            print(f"[promo-joins] lookups before={_before} matcher_calls={_PJ_CALLS} matches={_PJ_MATCHES} rejects={_PJ_REJECTS}", file=sys.stderr)


    def deduplicate_lateral_aliases(self, min_occurrences: int = 3) -> None:
        """Deduplicate repeated scalar subqueries in CTE WHERE clauses.

        Repeated correlated scalar subqueries are pulled into CROSS JOIN LATERAL
        derived tables and the WHERE clause is rewritten to reference the lateral
        value. This keeps the CTE's projected columns unchanged while avoiding
        repeated serialization of the same subquery.
        """
        for cte_def in self.ctes:
            self._dedup_cte(cte_def, min_occurrences)
            # Laterals may end up attached to a scope that cannot see their
            # references (transforms after dedup can relocate/wrap selects —
            # e.g. _ensure_resource_column wrapping). Unwrap any lateral whose
            # referenced aliases are not visible at its FINAL attach scope:
            # DuckDB raises "Referenced table X not found" at bind time
            # otherwise (CMS156 pattern: lateral referencing an alias defined
            # inside the FROM chain's derived tables).
            self._unwrap_scope_unsafe_laterals(cte_def.query)
        # The main query is validated too — laterals on the outermost select
        # have the same visibility constraints (review HIGH-1).
        self._unwrap_scope_unsafe_laterals(self.main_query)

    def _unwrap_scope_unsafe_laterals(
        self, node, outer_visible: frozenset = frozenset()
    ) -> None:
        """Recursively validate lateral joins and remove scope-unsafe ones.

        Uses the same scope CHAIN as the hoisting pass: a lateral is unsafe only
        when it references an alias that is in neither its own scope nor any
        enclosing one (DuckDB resolves outer references through the chain).
        """
        if node is None:
            return
        if isinstance(node, (list, tuple)):
            for item in node:
                self._unwrap_scope_unsafe_laterals(item, outer_visible)
            return
        if not hasattr(node, "__dataclass_fields__"):
            return

        if isinstance(node, SQLSelect):
            visible = set(outer_visible) | self._select_local_aliases(node)
            visible.add("_pt")
        else:
            visible = set(outer_visible)

        if isinstance(node, SQLSelect) and node.joins:
            kept_joins = []
            for join in node.joins:
                if (
                    isinstance(join, SQLJoin)
                    and join.join_type == "CROSS JOIN LATERAL"
                    and isinstance(join.table, SQLSelect)
                    and not self._lateral_join_scope_safe(join, visible)
                ):
                    # Unwrap: restore the original expression in place of
                    # <alias>.value references and drop the join.
                    lat_alias = join.alias
                    orig_expr = None
                    cols = join.table.columns or []
                    if cols and isinstance(cols[0], SQLAlias):
                        orig_expr = cols[0].expr
                    if orig_expr is not None and lat_alias:
                        node.columns = [
                            self._restore_lateral_ref(c, lat_alias, orig_expr)
                            for c in (node.columns or [])
                        ]
                        if node.where is not None:
                            node.where = self._restore_lateral_ref(
                                node.where, lat_alias, orig_expr
                            )
                    continue
                kept_joins.append(join)
            node.joins = kept_joins or None

        for field_name in node.__dataclass_fields__:
            self._unwrap_scope_unsafe_laterals(
                getattr(node, field_name, None), frozenset(visible)
            )

    def _lateral_join_scope_safe(self, join: "SQLJoin", visible: set) -> bool:
        """A lateral may reference only its attach scope's visible aliases
        (or aliases it defines internally). Nested-subquery references to
        visible aliases are allowed (DuckDB supports nested correlation to
        the lateral's own scope chain)."""
        internal = set()
        referenced = []
        stack = [join.table]
        seen = set()
        while stack:
            cur = stack.pop()
            if cur is None or id(cur) in seen:
                continue
            seen.add(id(cur))
            if isinstance(cur, SQLAlias):
                internal.add(cur.alias)
            elif isinstance(cur, SQLSelect) and cur.from_clause is not None:
                fr = cur.from_clause
                if isinstance(fr, SQLAlias):
                    internal.add(fr.alias)
                elif isinstance(fr, SQLIdentifier):
                    internal.add(fr.name)
            elif isinstance(cur, SQLQualifiedIdentifier) and cur.parts:
                referenced.append(cur.parts[0])
            if isinstance(cur, (list, tuple)):
                stack.extend(cur)
                continue
            for field_name in getattr(cur, "__dataclass_fields__", {}):
                stack.append(getattr(cur, field_name, None))
        return all(alias in internal or alias in visible for alias in referenced)

    def _restore_lateral_ref(self, node, lat_alias: str, orig_expr):
        """Replace `<lat_alias>.value` references with the original expression."""
        if node is None:
            return node
        if isinstance(node, SQLQualifiedIdentifier) and node.parts == [lat_alias, "value"]:
            return orig_expr
        if isinstance(node, (list, tuple)):
            new_items = [self._restore_lateral_ref(c, lat_alias, orig_expr) for c in node]
            return type(node)(new_items) if isinstance(node, tuple) else new_items
        if not hasattr(node, "__dataclass_fields__"):
            return node
        # Do not descend into nested query scopes: lateral references do
        # not occur there (laterals only replace projection/WHERE refs).
        if isinstance(node, (SQLSubquery, SQLExists)):
            return node
        changed = False
        for field_name in node.__dataclass_fields__:
            val = getattr(node, field_name, None)
            new_val = self._restore_lateral_ref(val, lat_alias, orig_expr)
            if new_val is not val:
                try:
                    setattr(node, field_name, new_val)
                    changed = True
                except Exception:
                    pass
        return node

    def _dedup_cte(self, cte_def: 'CTEDefinition', min_occ: int) -> None:
        """Apply lateral alias deduplication to a single CTE definition."""
        query = cte_def.query

        # Handle set operations: apply dedup to each operand individually
        if isinstance(query, (SQLUnion, SQLIntersect, SQLExcept)):
            for i, operand in enumerate(query.operands):
                inner = operand
                if isinstance(inner, SQLSubquery) and isinstance(inner.query, SQLSelect):
                    self._dedup_select(inner.query, min_occ)
                elif isinstance(inner, SQLSelect):
                    self._dedup_select(inner, min_occ)
            return

        # Handle plain SELECT CTE
        if isinstance(query, SQLSelect):
            self._dedup_select(query, min_occ)

    @staticmethod
    def _select_local_aliases(select: 'SQLSelect') -> set:
        """Aliases this select itself binds (FROM alias + JOIN aliases)."""
        local = set()
        for join in list(select.joins or []):
            if isinstance(join, SQLJoin):
                if join.alias:
                    local.add(join.alias)
                if isinstance(join.table, SQLAlias):
                    local.add(join.table.alias)
        if isinstance(select.from_clause, SQLAlias):
            local.add(select.from_clause.alias)
        elif isinstance(select.from_clause, SQLIdentifier):
            local.add(select.from_clause.name)
        return local

    def _dedup_select(
        self,
        select: 'SQLSelect',
        min_occ: int,
        outer_visible: frozenset = frozenset(),
    ) -> None:
        """Deduplicate repeated expressions in a SELECT's projection and WHERE.

        ``outer_visible`` carries the aliases of ENCLOSING selects. DuckDB
        resolves a lateral's references through its enclosing scopes (verified:
        2 and 3 levels up, and inside a UNION operand), so a repeated
        correlated extraction may be hoisted even when it references an alias
        that belongs to an ancestor rather than to this select. Without the
        chain the collector only saw this select's own aliases and rejected
        every such candidate (CMS2: 1.34 MB -> 12.95 MB, review BUGFIX-013).
        """
        # Aliases a LATERAL attached to THIS select may reference: its own FROM
        # alias + JOIN aliases, plus every enclosing select's (scope chain).
        local_aliases = self._select_local_aliases(select)
        visible = frozenset(outer_visible) | local_aliases

        # Recurse BEFORE hoisting here (children first), passing the right
        # visibility per position: a FROM-subquery or a non-lateral JOIN table
        # may NOT correlate to this select's aliases, while projection/WHERE
        # subqueries (and LATERAL tables) may.
        self._dedup_nested_scopes(select.columns, min_occ, visible)
        self._dedup_nested_scopes(select.from_clause, min_occ, frozenset(outer_visible))
        for join in list(select.joins or []):
            if isinstance(join, SQLJoin):
                is_lateral = "LATERAL" in (join.join_type or "").upper()
                self._dedup_nested_scopes(
                    join.table, min_occ, visible if is_lateral else frozenset(outer_visible)
                )
                self._dedup_nested_scopes(join.on_condition, min_occ, visible)
            else:
                self._dedup_nested_scopes(join, min_occ, frozenset(outer_visible))
        self._dedup_nested_scopes(select.where, min_occ, visible)

        if select.from_clause is None:
            return

        # (Star projections are qualified AFTER lateral construction —
        # see below — so appending laterals cannot widen them.)

        prev_aliases = getattr(self, "_current_dedup_aliases", None)
        self._current_dedup_aliases = visible
        try:
            # 1) Collect candidate expressions and their serialized forms.
            # Lateral aliases appended to this SELECT are visible to the projection
            # and WHERE clause, but not to earlier JOIN ON conditions.
            candidates = {}  # sql_str -> (node, count)
            self._collect_candidates(select.columns, candidates, min_occ)
            self._collect_candidates(select.where, candidates, min_occ)
        finally:
            self._current_dedup_aliases = prev_aliases

        if not candidates:
            return

        # 2) For each repeated expression, create a lateral derived table.
        lateral_joins = []
        alias_map = {}  # sql_str -> SQLQualifiedIdentifier
        for sql_str, (node, count) in sorted(
            candidates.items(),
            key=lambda item: -(len(item[0]) * item[1][1]),
        ):
            if count < min_occ:
                continue
            alias_name = f"_lat{len(lateral_joins)}"
            value_name = "value"
            alias_map[sql_str] = SQLQualifiedIdentifier(parts=[alias_name, value_name])
            lateral_joins.append(
                SQLJoin(
                    join_type="CROSS JOIN LATERAL",
                    table=SQLSelect(columns=[SQLAlias(expr=node, alias=value_name)]),
                    alias=alias_name,
                )
            )

        if not lateral_joins:
            return

        # Appending laterals widens a bare star projection (the lateral's
        # columns would join the FROM table's) — qualify the star with the
        # FROM alias (`a.*`) so the projection stays the FROM table's
        # columns only. Keeps UNION operand alignment (CMS-DEF-04/CMS22)
        # without skipping the dedup entirely (a skip exploded CMS0334
        # SQL 15x and hung the gate). When the select has JOINS, qualifying
        # would drop the joined tables' columns AND appending laterals
        # would widen the star — neither is safe, so skip the dedup for
        # star+joins selects entirely (review MEDIUM-8).
        _cols = select.columns or []
        _is_star = (
            len(_cols) == 1
            and isinstance(_cols[0], SQLIdentifier)
            and _cols[0].name == "*"
        )
        if _is_star and select.joins:
            return
        if _is_star:
            if isinstance(select.from_clause, SQLAlias):
                select.columns = [SQLQualifiedIdentifier(
                    parts=[select.from_clause.alias, "*"]
                )]
            elif isinstance(select.from_clause, SQLIdentifier):
                select.columns = [SQLQualifiedIdentifier(
                    parts=[select.from_clause.name, "*"]
                )]

        # 3) Replace occurrences in projection and WHERE with lateral references.
        select.columns = self._replace_alias_value(select.columns, alias_map)
        if select.where is not None:
            select.where = self._replace_aliases(select.where, alias_map)

        # 4) Append lateral joins after existing FROM/JOIN sources so they can
        # reference every alias visible to the WHERE clause.
        select.joins = list(select.joins or []) + lateral_joins

    def _dedup_nested_scopes(
        self, value: Any, min_occ: int, visible: frozenset = frozenset()
    ) -> None:
        """Apply deduplication inside nested SELECT scopes without hoisting out.

        ``visible`` is the enclosing alias chain passed to nested selects.
        """
        if value is None:
            return

        if isinstance(value, SQLSubquery):
            if isinstance(value.query, SQLSelect):
                self._dedup_select(value.query, min_occ, visible)
            elif isinstance(value.query, (SQLUnion, SQLIntersect, SQLExcept)):
                for operand in value.query.operands:
                    self._dedup_nested_scopes(operand, min_occ, visible)
            return

        if isinstance(value, SQLExists):
            self._dedup_nested_scopes(value.subquery, min_occ, visible)
            return

        if isinstance(value, SQLSelect):
            self._dedup_select(value, min_occ, visible)
            return

        if isinstance(value, SQLJoin):
            self._dedup_nested_scopes(value.table, min_occ, visible)
            self._dedup_nested_scopes(value.on_condition, min_occ, visible)
            return

        if isinstance(value, (SQLUnion, SQLIntersect, SQLExcept)):
            for operand in value.operands:
                self._dedup_nested_scopes(operand, min_occ)
            return

        if isinstance(value, list):
            for item in value:
                self._dedup_nested_scopes(item, min_occ)
            return

        if isinstance(value, tuple):
            for item in value:
                self._dedup_nested_scopes(item, min_occ)
            return

        if not is_dataclass(value):
            return

        for field_info in fields(value):
            self._dedup_nested_scopes(getattr(value, field_info.name), min_occ)

    def _collect_candidates(self, node: 'SQLExpression', candidates: dict, min_occ: int) -> None:
        """Walk the AST and collect scalar subqueries that appear multiple times."""
        if node is None:
            return

        if isinstance(node, (list, tuple)):
            for item in node:
                self._collect_candidates(item, candidates, min_occ)
            return

        if isinstance(node, dict):
            for item in node.values():
                self._collect_candidates(item, candidates, min_occ)
            return

        if isinstance(node, SQLSubquery):
            sql_str = node.to_sql()
            # Only consider larger correlated subqueries. Small subqueries do not
            # materially affect CMS1218 SQL size and are less worth the join churn.
            if 'patient_id' in sql_str and len(sql_str) > 200:
                if self._lateral_candidate_scope_safe(node):
                    count = candidates.get(sql_str, (None, 0))[1] + 1
                    candidates[sql_str] = (node, count)
            return

        if self._is_lateral_scalar_candidate(node):
            if self._lateral_candidate_scope_safe(node):
                sql_str = node.to_sql()
                count = candidates.get(sql_str, (None, 0))[1] + 1
                candidates[sql_str] = (node, count)
            return

        if isinstance(node, SQLExists):
            # EXISTS owns a nested SELECT scope. Hoisting an expression found only
            # inside that scope to the outer SELECT would be invalid.
            return

        for child in self._iter_child_expressions(node):
            self._collect_candidates(child, candidates, min_occ)

    def _lateral_candidate_scope_safe(self, node: 'SQLExpression') -> bool:
        """Whether hoisting this expression into a LATERAL is scope-safe.

        A CROSS JOIN LATERAL can only correlate to the aliases of the SELECT
        it is attached to — NOT to that SELECT's own outer-scope (correlated)
        aliases. A repeated subquery that references an outer-scope alias
        (CMS-DEF-01B/CMS135: fluent-inlined bodies referencing the query
        alias from deep EXISTS nesting) must keep its inline position, or
        DuckDB raises ``Referenced table "<alias>" not found`` at bind time.

        AST-level check: references to aliases the candidate DEFINES inside
        itself (its own FROM aliases) are fine; any other qualified
        reference must resolve to a local alias of the enclosing SELECT
        (``_current_dedup_aliases``) or ``_pt``.
        """
        local = self._current_dedup_aliases
        if local is None:
            return True

        internal: set = set()
        referenced: list = []
        stack = [node]
        seen = set()
        while stack:
            cur = stack.pop()
            if cur is None or id(cur) in seen:
                continue
            seen.add(id(cur))
            if isinstance(cur, SQLAlias):
                internal.add(cur.alias)
            elif isinstance(cur, SQLSelect) and cur.from_clause is not None:
                fr = cur.from_clause
                if isinstance(fr, SQLAlias):
                    internal.add(fr.alias)
                elif isinstance(fr, SQLIdentifier):
                    internal.add(fr.name)
            elif isinstance(cur, SQLQualifiedIdentifier) and cur.parts:
                referenced.append(cur.parts[0])
            # Bare identifiers are column references, not alias
            # qualifications — they cannot produce the "Referenced table
            # not found" binder class, so they are not tracked.
            if isinstance(cur, (list, tuple)):
                stack.extend(cur)
                continue
            for field_name in getattr(cur, "__dataclass_fields__", {}):
                stack.append(getattr(cur, field_name, None))

        for alias in referenced:
            if alias in internal or alias in local or alias == "_pt":
                continue
            return False
        return True

    @staticmethod
    def _is_lateral_scalar_candidate(node: Any) -> bool:
        """Return true for repeated pure scalar extractions worth lateralizing."""
        if not isinstance(node, SQLFunctionCall):
            return False
        if not node.name or node.name.lower() not in {"fhirpath", "fhirpath_text"}:
            return False
        if len(node.args) < 2:
            return False
        # Very small direct field reads are usually cheaper than an extra lateral
        # join. Complex first args, such as scalar subqueries, remain eligible.
        if len(node.to_sql()) <= 80 and isinstance(
            node.args[0], (SQLIdentifier, SQLQualifiedIdentifier)
        ):
            return False
        return True

    def _replace_aliases(self, node: 'SQLExpression', alias_map: dict) -> 'SQLExpression':
        """Replace subexpressions matching alias_map keys with qualified aliases."""
        # Check if this node itself should be replaced
        if isinstance(node, SQLSubquery):
            sql_str = node.to_sql()
            if sql_str in alias_map:
                return alias_map[sql_str]
            return node

        if self._is_lateral_scalar_candidate(node):
            sql_str = node.to_sql()
            if sql_str in alias_map:
                return alias_map[sql_str]

        if isinstance(node, SQLExists):
            return node

        if not is_dataclass(node):
            return node

        for field_info in fields(node):
            value = getattr(node, field_info.name)
            new_value = self._replace_alias_value(value, alias_map)
            if new_value is not value:
                setattr(node, field_info.name, new_value)
        return node

    def _iter_child_expressions(self, value: Any) -> List['SQLExpression']:
        """Return SQLExpression children without crossing SELECT/subquery scopes."""
        children: List[SQLExpression] = []

        def visit(item: Any) -> None:
            if isinstance(item, SQLExpression):
                children.append(item)
                return
            if isinstance(item, (list, tuple)):
                for sub_item in item:
                    visit(sub_item)
                return
            if isinstance(item, dict):
                for sub_item in item.values():
                    visit(sub_item)

        if is_dataclass(value):
            for field_info in fields(value):
                field_value = getattr(value, field_info.name)
                visit(field_value)
        return children

    def _replace_alias_value(self, value: Any, alias_map: dict) -> Any:
        """Recursively rewrite SQLExpression values inside dataclass containers."""
        if isinstance(value, SQLExpression):
            return self._replace_aliases(value, alias_map)

        if isinstance(value, list):
            changed = False
            new_items = []
            for item in value:
                new_item = self._replace_alias_value(item, alias_map)
                if new_item is not item:
                    changed = True
                new_items.append(new_item)
            return new_items if changed else value

        if isinstance(value, tuple):
            changed = False
            new_items = []
            for item in value:
                new_item = self._replace_alias_value(item, alias_map)
                if new_item is not item:
                    changed = True
                new_items.append(new_item)
            return tuple(new_items) if changed else value

        if isinstance(value, dict):
            changed = False
            new_items = {}
            for key, item in value.items():
                new_item = self._replace_alias_value(item, alias_map)
                if new_item is not item:
                    changed = True
                new_items[key] = new_item
            return new_items if changed else value

        return value


@dataclass
class SQLParameterRef(SQLExpression):
    """
    Represents a reference to a CQL parameter.

    Parameters are passed as prepared statement parameters.
    """

    name: str
    precedence: int = PRECEDENCE["PRIMARY"]

    def to_sql(self, parent_precedence: int = 0) -> str:
        # Normalize parameter name for DuckDB session variable:
        # - Convert spaces to underscores
        # - Convert to lowercase
        # - Use getvariable() for session variables
        # - CAST to VARCHAR since getvariable returns a string literal type
        normalized_name = self.name.replace(" ", "_").lower().replace("'", "''")
        return f"CAST(getvariable('{normalized_name}') AS VARCHAR)"


VALID_INTERVAL_UNITS = {"year", "month", "week", "day", "hour", "minute", "second"}


@dataclass
class SQLIntervalLiteral(SQLExpression):
    """SQL INTERVAL literal (e.g., INTERVAL '5 day'). Not to be confused with
    SQLInterval which represents FHIR value intervals."""
    value: int
    unit: str

    precedence: int = PRECEDENCE["PRIMARY"]

    def to_sql(self, parent_precedence: int = 0) -> str:
        unit = self.unit.lower()
        # Normalize plural forms (e.g., 'days' -> 'day', 'months' -> 'month')
        if unit.endswith("s") and unit[:-1] in VALID_INTERVAL_UNITS:
            unit = unit[:-1]
        if unit not in VALID_INTERVAL_UNITS:
            raise ValueError(f"Invalid interval unit: {self.unit}")
        return f"INTERVAL '{self.value} {unit}'"


@dataclass
class SQLNull(SQLExpression):
    """
    Represents a NULL literal.
    """

    precedence: int = PRECEDENCE["PRIMARY"]

    def to_sql(self, parent_precedence: int = 0) -> str:
        return "NULL"


@dataclass
class SQLUnion(SQLExpression):
    """
    Represents a UNION or UNION ALL expression in SQL.

    Used for combining multiple SELECT statements.

    CQL semantics: Union should deduplicate by default (UNION, not UNION ALL).
    Only use UNION ALL when sources are provably disjoint (different resource types).
    """

    operands: List[SQLExpression] = field(default_factory=list)
    distinct: bool = True  # UNION by default (CQL semantics - deduplicate)
    precedence: int = PRECEDENCE["UNION"]

    def to_sql(self, parent_precedence: int = 0) -> str:
        if not self.operands:
            return "SELECT NULL WHERE FALSE"

        union_keyword = "UNION" if self.distinct else "UNION ALL"

        def _normalize_operand(op: "SQLExpression") -> str:
            """Render an operand for UNION, normalizing column lists."""
            if isinstance(op, SQLIdentifier) and op.quoted:
                wrapper = SQLSelect(
                    columns=[SQLIdentifier(name="patient_id"), SQLIdentifier(name="resource")],
                    from_clause=op,
                )
                return wrapper.to_sql(self.precedence)
            elif isinstance(op, SQLSubquery) and isinstance(op.query, SQLIdentifier) and op.query.quoted:
                wrapper = SQLSelect(
                    columns=[SQLIdentifier(name="patient_id"), SQLIdentifier(name="resource")],
                    from_clause=op.query,
                )
                return wrapper.to_sql(self.precedence)
            elif isinstance(op, SQLSubquery) and isinstance(op.query, SQLSelect):
                inner = op.query
                cols = inner.columns or []
                # Detect SELECT * from a quoted CTE — replace with explicit patient_id, resource
                # to prevent column count mismatches when CTEs have extra precomputed columns
                # (e.g., status). Keep the WHERE clause and FROM alias intact.
                is_star = (len(cols) == 1 and isinstance(cols[0], SQLIdentifier) and cols[0].name == "*")
                if is_star:
                    from_clause = inner.from_clause
                    from_ident = None
                    if isinstance(from_clause, SQLAlias) and isinstance(from_clause.expr, SQLIdentifier) and from_clause.expr.quoted:
                        from_ident = from_clause.expr
                    elif isinstance(from_clause, SQLIdentifier) and from_clause.quoted:
                        from_ident = from_clause
                    if from_ident:
                        normalized = SQLSelect(
                            columns=[SQLIdentifier(name="patient_id"), SQLIdentifier(name="resource")],
                            from_clause=inner.from_clause,
                            where=inner.where,
                        )
                        return f"({normalized.to_sql(self.precedence)})"
                # Detect single-column SELECT missing patient_id (e.g., tuple
                # expressions that produce only a 'resource' column).  Add patient_id
                # from the source so UNION operands have matching column counts.
                if len(cols) == 1:
                    col = cols[0]
                    col_name = None
                    if isinstance(col, SQLIdentifier):
                        col_name = col.name
                    elif isinstance(col, SQLAlias):
                        col_name = col.alias
                    if col_name and col_name not in ("patient_id", "*"):
                        # Qualify the patient_id from the FROM alias if present
                        pid_col: SQLExpression
                        from_clause = inner.from_clause
                        alias_name = None
                        if isinstance(from_clause, SQLAlias):
                            alias_name = from_clause.alias
                        if alias_name:
                            pid_col = SQLQualifiedIdentifier(parts=[alias_name, "patient_id"])
                        else:
                            pid_col = SQLIdentifier(name="patient_id")
                        normalized = SQLSelect(
                            columns=[pid_col, col],
                            from_clause=inner.from_clause,
                            where=inner.where,
                            # CORE-012: preserve the full clause set — the
                            # old reconstruction dropped joins/group_by/having,
                            # silently changing aggregate/joined operands.
                            joins=inner.joins,
                            group_by=inner.group_by,
                            having=inner.having,
                            order_by=inner.order_by,
                            limit=inner.limit,
                            distinct=inner.distinct,
                        )
                        return f"({normalized.to_sql(self.precedence)})"
                return op.to_sql(self.precedence)
            else:
                return op.to_sql(self.precedence)

        operand_sqls = []
        for idx, op in enumerate(self.operands):
            sql = _normalize_operand(op)
            if idx > 0 and _is_set_operation_node(op):
                sql = f"({sql})"
            operand_sqls.append(sql)
        result = f" {union_keyword} ".join(operand_sqls)

        if self.needs_parentheses(parent_precedence):
            return f"({result})"

        return result


def _is_set_operation_node(op) -> bool:
    """True for UNION / INTERSECT / EXCEPT nodes (set-operation operands).

    Resolved at call time — SQLIntersect/SQLExcept are defined below this
    helper in the module.
    """
    return isinstance(op, (SQLUnion, SQLIntersect, SQLExcept))


def _flatten_except_union_operands(operands) -> list:
    """Rewrite ``X except (Y union Z)`` into ``X except Y except Z``.

    Set difference distributes over union ONLY on the subtracted side —
    ``X \\ (Y ∪ Z) = (X \\ Y) \\ Z`` — so the flattened form is semantically
    identical and needs no parentheses. SQL's UNION / INTERSECT / EXCEPT share
    one precedence level and are left-associative, so the un-flattened text
    ``X EXCEPT Y UNION Z`` evaluates as ``(X except Y) union Z`` and RE-ADDS
    every Z member. This was the CMS1028 false-positive Numerator Exclusion
    (patients whose only evidence was a ventilation procedure returned through
    the union arm of the except's right side). Flattening also keeps the fast
    SQL shape: parenthesizing the right operand compiles but defeats DuckDB's
    set-operation planning.

    NEVER pass the minuend (operand 0) here. ``(A ∪ B) \\ C`` is not
    ``(A \\ B) \\ C``: flattening the first operand subtracts B from A and
    silently loses B's rows (review REV-003).
    """
    flat = []
    for op in operands:
        if isinstance(op, SQLUnion):
            flat.extend(_flatten_except_union_operands(op.operands))
        else:
            flat.append(op)
    return flat


def _render_set_operands(operands, keyword: str, precedence: int) -> str:
    """Render set-operation operands with correct grouping.

    ``EXCEPT`` flattens union operands (see
    :func:`_flatten_except_union_operands`). Any remaining nested set
    operation in a NON-FIRST position is parenthesized, because SQL's
    UNION / INTERSECT / EXCEPT share one precedence level and are
    left-associative — without parentheses the tree would flatten. First
    position needs none: left-associative evaluation already matches the tree.
    """
    if keyword == "EXCEPT":
        # Only the SUBTRACTED operands may be flattened: X ∖ (Y ∪ Z) =
        # (X ∖ Y) ∖ Z holds, but (A ∪ B) ∖ C ≠ (A ∖ B) ∖ C. Flattening the
        # minuend silently drops the union's non-first branches (REV-003).
        operands = [operands[0], *_flatten_except_union_operands(list(operands[1:]))]
    parts = []
    for idx, op in enumerate(operands):
        sql = _normalize_set_operand(op, precedence)
        if idx > 0 and _is_set_operation_node(op):
            sql = f"({sql})"
        parts.append(sql)
    return f" {keyword} ".join(parts)


def _normalize_set_operand(op: "SQLExpression", precedence: int) -> str:
    """Normalize a UNION/INTERSECT/EXCEPT operand to (patient_id, resource).

    Handles:
    - Bare quoted CTE identifiers → SELECT patient_id, resource FROM "CTE"
    - SELECT * FROM "CTE" → SELECT patient_id, resource FROM "CTE"
    - SELECT resource FROM "CTE" → SELECT patient_id, resource FROM "CTE"
    """
    if isinstance(op, SQLIdentifier) and op.quoted:
        wrapper = SQLSelect(
            columns=[SQLIdentifier(name="patient_id"), SQLIdentifier(name="resource")],
            from_clause=op,
        )
        return wrapper.to_sql(precedence)
    elif isinstance(op, SQLSubquery) and isinstance(op.query, SQLSelect):
        inner = op.query
        cols = inner.columns or []
        # Detect SELECT * or SELECT resource (single column from CTE).
        # Also handles qualified form SELECT sub.resource (SQLQualifiedIdentifier)
        # which is generated when the DuckDB alias self-reference bug fix is active.
        needs_normalize = False
        if len(cols) == 1:
            col = cols[0]
            if isinstance(col, SQLIdentifier) and col.name in ("*", "resource"):
                needs_normalize = True
            elif isinstance(col, SQLQualifiedIdentifier) and col.parts and col.parts[-1] in ("*", "resource"):
                needs_normalize = True
        if needs_normalize:
            # Strip LIMIT from set operation operands — set operations
            # (UNION/INTERSECT/EXCEPT) need ALL matching rows, not just
            # the first.  LIMIT 1 is added by SCALAR-context translation
            # but is incorrect for set operation arms.
            normalized = SQLSelect(
                columns=[SQLIdentifier(name="patient_id"),
                         SQLIdentifier(name="resource")],
                from_clause=inner.from_clause,
                where=inner.where,
                order_by=inner.order_by,
                distinct=inner.distinct,
                joins=inner.joins,
                group_by=inner.group_by,
                having=inner.having,
            )
            return f"({normalized.to_sql(precedence)})"
        return op.to_sql(precedence)
    else:
        return op.to_sql(precedence)


@dataclass
class SQLIntersect(SQLExpression):
    """
    Represents an INTERSECT expression in SQL.

    Used for CQL list intersect on row-producing queries.
    """

    operands: List[SQLExpression] = field(default_factory=list)
    precedence: int = PRECEDENCE["INTERSECT"]

    def to_sql(self, parent_precedence: int = 0) -> str:
        if not self.operands:
            return "SELECT NULL WHERE FALSE"

        result = _render_set_operands(self.operands, "INTERSECT", self.precedence)

        if self.needs_parentheses(parent_precedence):
            return f"({result})"

        return result


@dataclass
class SQLExcept(SQLExpression):
    """
    Represents an EXCEPT expression in SQL.

    Used for CQL list except on row-producing queries.
    """

    operands: List[SQLExpression] = field(default_factory=list)
    precedence: int = PRECEDENCE["UNION"]

    def to_sql(self, parent_precedence: int = 0) -> str:
        if not self.operands:
            return "SELECT NULL WHERE FALSE"

        result = _render_set_operands(self.operands, "EXCEPT", self.precedence)

        if self.needs_parentheses(parent_precedence):
            return f"({result})"

        return result


@dataclass
class SQLWindowFunction(SQLExpression):
    """
    Represents a window function call in SQL.

    Examples:
        ROW_NUMBER() OVER (PARTITION BY patient_ref ORDER BY date DESC)
        SUM(amount) OVER (PARTITION BY customer_id)
        COUNT(*) OVER (PARTITION BY department ORDER BY hire_date)
    """

    function: str  # e.g., "ROW_NUMBER", "SUM", "COUNT"
    function_args: List[SQLExpression] = field(default_factory=list)
    partition_by: List[SQLExpression] = field(default_factory=list)
    order_by: List[tuple] = field(default_factory=list)  # List of (expr, 'ASC'|'DESC')
    frame_clause: Optional[str] = None  # e.g., "ROWS BETWEEN UNBOUNDED PRECEDING AND CURRENT ROW"
    precedence: int = PRECEDENCE["FUNCTION"]

    def to_sql(self, parent_precedence: int = 0) -> str:
        # Function call
        if self.function_args:
            args_sql = ", ".join(arg.to_sql() for arg in self.function_args)
            func_sql = f"{self.function}({args_sql})"
        else:
            func_sql = f"{self.function}()"

        # OVER clause
        over_parts = []

        if self.partition_by:
            partition_sql = ", ".join(p.to_sql() for p in self.partition_by)
            over_parts.append(f"PARTITION BY {partition_sql}")

        if self.order_by:
            order_parts = []
            for expr, direction in self.order_by:
                order_parts.append(f"{expr.to_sql()} {direction}")
            over_parts.append(f"ORDER BY {', '.join(order_parts)}")

        if self.frame_clause:
            over_parts.append(self.frame_clause)

        over_clause = " ".join(over_parts)
        result = f"{func_sql} OVER ({over_clause})"

        if self.needs_parentheses(parent_precedence):
            return f"({result})"

        return result


# Type alias for any SQL expression
SQLExpressionType = Union[
    SQLLiteral,
    SQLIdentifier,
    SQLQualifiedIdentifier,
    SQLFunctionCall,
    SQLBinaryOp,
    SQLUnaryOp,
    SQLCase,
    SQLArray,
    SQLList,
    SQLLambda,
    SQLLambda2,
    SQLInterval,
    SQLCast,
    SQLSelect,
    SQLJoin,
    SQLSubquery,
    SQLExists,
    SQLUnion,
    SQLWindowFunction,
    SQLParameterRef,
    SQLNull,
]


# =============================================================================
# Context Types for Translation
# =============================================================================


@dataclass
class SymbolInfo:
    """
    Information about a symbol (variable, alias, or definition) in scope.

    Attributes:
        name: Symbol name.
        cql_type: CQL type (e.g., 'Patient', 'List<Condition>').
        sql_ref: SQL reference (column name or expression).
        source_alias: Optional source table alias.
        is_list: Whether this symbol represents a list value.
        nullable: Whether this symbol can be null.
    """

    name: str
    cql_type: str
    sql_ref: str = ""
    source_alias: Optional[str] = None
    is_list: bool = False
    nullable: bool = True


@dataclass
class ParameterBinding:
    """
    Represents a CQL parameter binding.

    Attributes:
        name: Parameter name.
        param_type: CQL type string.
        default_value: Optional default value.
        value: Runtime value (if set).
    """

    name: str
    param_type: str
    default_value: Any = None
    value: Any = None


@dataclass
class FunctionInfo:
    """
    Information about a CQL function definition.

    Attributes:
        name: Function name.
        parameters: List of (name, type) tuples.
        return_type: Return type.
        body: Function body AST node.
        fluent: Whether this is a fluent function.
    """

    name: str
    parameters: List[tuple] = field(default_factory=list)  # List of (name, type)
    return_type: str = "Any"
    body: Any = None  # AST node for function body
    fluent: bool = False


@dataclass
class LibraryInfo:
    """
    Information about an included CQL library.

    Attributes:
        name: Library name.
        version: Library version.
        alias: Local alias for the library.
        definitions: Named definitions from the library.
        functions: Functions defined in the library.
    """

    name: str
    version: Optional[str] = None
    alias: Optional[str] = None
    definitions: Dict[str, Any] = field(default_factory=dict)
    functions: Dict[str, FunctionInfo] = field(default_factory=dict)


@dataclass
class PatientContext:
    """
    Patient context for single-patient evaluation.

    Attributes:
        patient_id: Current patient ID.
        patient_resource: Full patient FHIR resource (if loaded).
    """

    patient_id: Optional[str] = None
    patient_resource: Optional[Dict[str, Any]] = None

    def is_set(self) -> bool:
        """Check if patient context is configured."""
        return self.patient_id is not None


@dataclass
class QuerySource:
    """
    Represents a query source (table, CTE, or subquery).

    Attributes:
        name: Source name (table name, CTE name, or alias).
        sql_expr: SQL expression for the source.
        resource_type: FHIR resource type (if applicable).
        alias: Query alias for this source.
    """

    name: str
    sql_expr: SQLExpression
    resource_type: Optional[str] = None
    alias: str = ""


# ---------------------------------------------------------------------------
# Audit-mode types — used when CQLToSQLTranslator(audit_mode=True)
# ---------------------------------------------------------------------------


@dataclass
class SQLEvidenceItem(SQLExpression):
    """A single evidence item: struct_pack(target, attribute, value, operator, threshold, trace)."""

    target: SQLExpression = field(default_factory=lambda: SQLNull())
    attribute: SQLExpression = field(default_factory=lambda: SQLNull())
    value: SQLExpression = field(default_factory=lambda: SQLNull())
    operator_str: str = ""
    threshold: SQLExpression = field(default_factory=lambda: SQLNull())
    trace: list = field(default_factory=list)
    precedence: int = PRECEDENCE["PRIMARY"]

    def to_sql(self, parent_precedence: int = 0) -> str:
        # Cast nullable fields to VARCHAR to prevent DuckDB inferring NULL as INTEGER,
        # which causes type-mismatch errors when concatenating evidence lists whose
        # _audit_item structs were created with different NULL-default types.
        def _varchar(expr: "SQLExpression") -> str:
            sql = expr.to_sql()
            if sql == "NULL":
                return "CAST(NULL AS VARCHAR)"
            return sql

        if self.trace:
            trace_items = ", ".join(f"'{v.replace(chr(39), chr(39)+chr(39))}'" for v in self.trace)
            trace_sql = f"CAST(list_value({trace_items}) AS VARCHAR[])"
        else:
            trace_sql = "CAST([] AS VARCHAR[])"

        return (
            f"struct_pack("
            f"target := {self.target.to_sql()}, "
            f"attribute := {_varchar(self.attribute)}, "
            f"value := {_varchar(self.value)}, "
            f"operator := '{self.operator_str}', "
            f"threshold := {_varchar(self.threshold)}, "
            f"trace := {trace_sql}"
            f")"
        )


@dataclass
class SQLAuditStruct(SQLExpression):
    """struct_pack(result := <bool_expr>, evidence := <evidence_item_array>)."""

    result_expr: SQLExpression = field(default_factory=lambda: SQLLiteral(value=False))
    evidence_expr: SQLExpression = field(default_factory=lambda: SQLArray())
    precedence: int = PRECEDENCE["PRIMARY"]

    def to_sql(self, parent_precedence: int = 0) -> str:
        return (
            f"struct_pack("
            f"result := {self.result_expr.to_sql()}, "
            f"evidence := {self.evidence_expr.to_sql()}"
            f")"
        )


__all__ = [
    # Precedence
    "PRECEDENCE",
    # Base class
    "SQLExpression",
    # Literals and identifiers
    "SQLLiteral",
    "SQLRaw",
    "SQLExtract",
    "SQLIdentifier",
    "SQLQualifiedIdentifier",
    "SQLNull",
    "SQLParameterRef",
    # Operators
    "SQLBinaryOp",
    "SQLUnaryOp",
    # Functions and expressions
    "SQLFunctionCall",
    "SQLCase",
    "SQLArray",
    "SQLList",
    "SQLLambda",
    "SQLLambda2",
    "SQLInterval",
    "SQLCast",
    "SQLAlias",
    # Queries
    "SQLSelect",
    "SQLJoin",
    "SQLSubquery",
    "SQLExists",
    "SQLUnion",
    "SQLWindowFunction",
    # CTEs
    "CTEDefinition",
    "SQLRetrieveCTE",
    "deduplicate_retrieve_ctes",
    "SQLFragment",
    # Default sort columns for First()/Last() determinism
    # Type alias
    "SQLExpressionType",
    # Context types
    "SymbolInfo",
    "ParameterBinding",
    "FunctionInfo",
    "LibraryInfo",
    "PatientContext",
    "QuerySource",
    # Audit types
    "SQLEvidenceItem",
    "SQLAuditStruct",
]


# ---------------------------------------------------------------------------
# AMUX-126: promotion-lookup → LEFT JOIN rewrite
# ---------------------------------------------------------------------------

def _promotions_bound_aliases(select: "SQLSelect") -> set:
    """Aliases visible to expressions of this select: the FROM alias plus
    every JOIN alias (lateral or not — laterals see earlier bindings)."""
    names = set()
    fc = select.from_clause
    if isinstance(fc, SQLAlias) and fc.alias:
        names.add(fc.alias)
    for join in select.joins or []:
        if isinstance(join, SQLJoin) and join.alias:
            names.add(join.alias)
        elif isinstance(join, SQLJoin) and isinstance(join.table, SQLAlias) and join.table.alias:
            names.add(join.table.alias)
    return names


def _promotions_match_lookup(node, available: set, from_alias=None):
    """Match the promotion-lookup scalar-subquery shape.

    Returns (cte_name, src_alias, row_key_expr, value_alias) or None.
    """
    if not isinstance(node, SQLSubquery):
        return None
    q = node.query
    if not isinstance(q, SQLSelect) or q.group_by or q.having or q.joins:
        return None
    _dbg = _PJ_DEBUG
    # projection must be exactly the value column
    if len(q.columns) != 1 or not isinstance(q.columns[0], SQLIdentifier) or q.columns[0].name != "value":
        if _dbg:
            _pj_reject("columns", q.columns)
        return None
    fc = q.from_clause
    if not isinstance(fc, SQLAlias):
        if _dbg:
            _pj_reject("from_clause", fc)
        return None
    cte = fc.expr
    if not isinstance(cte, SQLIdentifier) or not cte.quoted:
        if _dbg:
            _pj_reject("cte_ident", fc.expr)
        return None
    if fc.alias is None:
        if _dbg:
            _pj_reject("alias_none", fc)
        return None
    value_alias = fc.alias
    w = q.where
    if not isinstance(w, SQLBinaryOp) or (w.operator or "").upper() != "AND":
        if _dbg:
            _pj_reject("where_shape", w)
        return None

    def _eq_parts(op):
        # match X = Y where one side is <a>.patient_id / <a>._row_key with
        # a == value_alias; return (kind, other_expr)
        if not isinstance(op, SQLBinaryOp) or (op.operator or "") != "=":
            return None
        for lhs, rhs in ((op.left, op.right), (op.right, op.left)):
            if (
                isinstance(lhs, SQLQualifiedIdentifier)
                and len(lhs.parts) == 2
                and lhs.parts[0] == value_alias
            ):
                kind = lhs.parts[1]
                if kind in ("patient_id", "_row_key"):
                    return (kind, rhs)
        return None

    a = _eq_parts(w.left)
    b = _eq_parts(w.right)
    if a is None or b is None:
        if _dbg:
            _pj_reject("eq_sides", (w.left, w.right))
        return None
    kinds = {a[0], b[0]}
    if kinds != {"patient_id", "_row_key"}:
        if _dbg:
            _pj_reject("kinds", (a[0], b[0]))
        return None
    pid_other = a[1] if a[0] == "patient_id" else b[1]
    key_other = a[1] if a[0] == "_row_key" else b[1]
    # patient_id side must be <src>.patient_id with src bound at this scope
    if not (
        isinstance(pid_other, SQLQualifiedIdentifier)
        and len(pid_other.parts) == 2
        and pid_other.parts[1] == "patient_id"
        and pid_other.parts[0] in available
    ):
        if _dbg:
            _pj_reject(
                "pid_src",
                getattr(pid_other, "parts", pid_other),
            )
        return None
    src_alias = pid_other.parts[0]
    # Review hardening (LOW-MED): the rewritten join is PREPENDED at index 0,
    # so its ON may only reference the FROM alias — a lookup correlating on a
    # lateral-join alias would emit an ON referencing an alias bound by a
    # LATER join (DuckDB binder error). Reject anything but the FROM alias
    # when the caller threads it in.
    if from_alias is not None and src_alias != from_alias:
        return None
    # row-key expression must reference ONLY the source alias (no sibling
    # tables), so the join ON is evaluable from FROM+earlier joins alone
    refs = set()

    def _collect_refs(n):
        if isinstance(n, SQLQualifiedIdentifier):
            if len(n.parts) >= 2:
                refs.add(n.parts[0])
        elif isinstance(n, SQLFunctionCall):
            for arg in n.args or []:
                _collect_refs(arg)
        elif isinstance(n, SQLBinaryOp):
            _collect_refs(n.left)
            _collect_refs(n.right)
        elif isinstance(n, SQLUnaryOp):
            _collect_refs(n.operand)
        elif isinstance(n, SQLCase):
            for cond, res in n.when_clauses or []:
                _collect_refs(cond)
                _collect_refs(res)
            if n.else_clause is not None:
                _collect_refs(n.else_clause)
        elif isinstance(n, SQLCast):
            _collect_refs(n.expression)

    _collect_refs(key_other)
    if refs - {src_alias}:
        if _dbg:
            _pj_reject("key_refs", refs)
        return None
    return (cte.name, src_alias, key_other, value_alias)


def _promotions_rewrite_select(select, _global_counter=None) -> None:
    """Rewrite promotion lookups within one select's own scope, then recurse
    into child selects (nested subqueries are separate scopes UNLESS they do
    not shadow any of this scope's aliases)."""
    if isinstance(select, SQLUnion):
        for arm in select.operands or []:
            if isinstance(arm, SQLSelect):
                _promotions_rewrite_select(arm)
            elif isinstance(arm, SQLSubquery):
                _promotions_rewrite_select(arm.query)
            elif isinstance(arm, SQLAlias):
                inner = arm.expr
                if isinstance(inner, SQLSelect):
                    _promotions_rewrite_select(inner)
                elif isinstance(inner, SQLSubquery):
                    _promotions_rewrite_select(inner.query)
        return
    if not isinstance(select, SQLSelect):
        return
    # FIX (AMUX-126 review): ONE fragment-global alias counter — per-scope
    # counters let a child-scope pass and an enclosing-scope pass mint the
    # SAME _fvjN inside one subquery; DuckDB resolves the innermost binding,
    # silently hijacking the outer join reference (CMS0334/CMS1028 false
    # positives: the EGA timing window degenerated to trivially true).
    if _global_counter is None:
        _global_counter = [0]
    # Process nested selects first (bottom-up): each gets its own rewrite.
    for child in _promotions_child_selects(select):
        _promotions_rewrite_select(child, _global_counter)

    available = _promotions_bound_aliases(select)
    if not available:
        return
    # collect matches across this select's own expressions (not descending
    # into non-shadowing child selects yet — handled below)
    joins_added: dict = {}
    counter = _global_counter
    select.columns = [
        _promotions_rewrite_expr(c, available, joins_added, counter, select)
        for c in (select.columns or [])
    ]
    if select.where is not None:
        select.where = _promotions_rewrite_expr(
            select.where, available, joins_added, counter, select
        )
    # Snapshot the join list: the rewriter PREPENDS new joins to
    # select.joins, and iterating the live list while prepending shifts
    # every element right, starving later joins (the lateral bodies after
    # the insertion point were never visited).
    for join in list(select.joins or []):
        if isinstance(join, SQLJoin):
            if join.on_condition is not None:
                join.on_condition = _promotions_rewrite_expr(
                    join.on_condition, available, joins_added, counter, select
                )
            _lat_sel = None
            if isinstance(join.table, SQLSelect):
                _lat_sel = join.table
            elif isinstance(join.table, SQLSubquery):
                _lat_sel = join.table.query
            elif isinstance(join.table, SQLAlias) and isinstance(join.table.expr, SQLSelect):
                _lat_sel = join.table.expr
            if _lat_sel is not None:
                # lateral body: same scope for outer aliases if the lateral
                # does not shadow them; its own scope is processed via the
                # child-selects pass
                shadowed = _promotions_bound_aliases(_lat_sel) & available
                if not shadowed:
                    _lat_sel.columns = [
                        _promotions_rewrite_expr(c, available, joins_added, counter, select)
                        for c in (_lat_sel.columns or [])
                    ]
                    if _lat_sel.where is not None:
                        _lat_sel.where = _promotions_rewrite_expr(
                            _lat_sel.where, available, joins_added, counter, select
                        )


_PJ_DEBUG = False
_PJ_CALLS = 0
_PJ_MATCHES = 0
_PJ_REJECTS: "dict[str, int]" = {}


def _pj_reject(reason: str, obj=None) -> None:
    _PJ_REJECTS[reason] = _PJ_REJECTS.get(reason, 0) + 1
    if _PJ_REJECTS[reason] == 1 and obj is not None:
        import sys
        print(f"[promo-joins] reject[{reason}]: {type(obj).__name__} {str(obj)[:140]!r}", file=sys.stderr)


def _promotions_rewrite_expr(node, available, joins_added, counter, select):
    """Recursively rewrite within an expression tree. Returns the replacement."""
    if node is None or isinstance(node, (str, int, float, bool)):
        return node
    if _PJ_DEBUG:
        global _PJ_CALLS, _PJ_MATCHES
        _PJ_CALLS += 1
    _fa = None
    if isinstance(select.from_clause, SQLAlias) and select.from_clause.alias:
        _fa = select.from_clause.alias
    match = _promotions_match_lookup(node, available, from_alias=_fa)
    if _PJ_DEBUG and match is not None:
        _PJ_MATCHES += 1
    if match is not None:
        cte_name, src_alias, key_expr, _va = match
        key_sql = key_expr.to_sql()
        jkey = (cte_name, src_alias, key_sql)
        if jkey not in joins_added:
            join_alias = f"_fvj{counter[0]}"
            join_alias_src = f"_fvjs{counter[0]}"
            counter[0] += 1
            src_pid = SQLQualifiedIdentifier(parts=[src_alias, "patient_id"])
            on = SQLBinaryOp(
                operator="AND",
                left=SQLBinaryOp(
                    operator="=",
                    left=SQLQualifiedIdentifier(parts=[join_alias, "_pj_pid"]),
                    right=src_pid,
                ),
                right=SQLBinaryOp(
                    operator="=",
                    left=SQLQualifiedIdentifier(parts=[join_alias, "_pj_rk"]),
                    right=key_expr,
                ),
            )
            # Wrap the CTE in a projection-renaming subquery: the join then
            # exposes ONLY `value` (plus the renamed key columns), so it can
            # never make an unqualified `patient_id` / `_row_key` / `value`
            # in the consumer's projection ambiguous (the CMS2 element-value
            # shapes all project bare patient_id).
            _wrapped = SQLSubquery(
                query=SQLSelect(
                    columns=[
                        SQLAlias(
                            expr=SQLQualifiedIdentifier(parts=[join_alias_src, "patient_id"]),
                            alias="_pj_pid",
                        ),
                        SQLAlias(
                            expr=SQLQualifiedIdentifier(parts=[join_alias_src, "_row_key"]),
                            alias="_pj_rk",
                        ),
                        SQLQualifiedIdentifier(parts=[join_alias_src, "value"]),
                    ],
                    from_clause=SQLAlias(
                        expr=SQLIdentifier(name=cte_name, quoted=True),
                        alias=join_alias_src,
                    ),
                )
            )
            join = SQLJoin(
                join_type="LEFT",
                table=_wrapped,
                alias=join_alias,
                on_condition=on,
            )
            # Prepend: the ON references only the FROM alias, so the join is
            # valid at position 0 and its alias is visible everywhere later.
            if select.joins is None:
                select.joins = [join]
            else:
                select.joins.insert(0, join)
            joins_added[jkey] = join_alias
        join_alias = joins_added[jkey]
        repl = SQLQualifiedIdentifier(parts=[join_alias, "value"])
        # Preserve the list-valued tag the lookup carried (CMS0334
        # in_valueset list-guard contract).
        rt = getattr(node, "result_type", None)
        if rt:
            repl.result_type = rt
        return repl
    # generic recursion: descend into EVERY dataclass field that holds
    # SQL expressions (covers SQLExists.subquery, SQLIn, SQLBetween and any
    # other composite the hardcoded lists would miss — the CMS2 consumer
    # lookups live under SQLExists.subquery chains and SQLCase.when_clauses).
    import dataclasses as _dc

    def _rw(value):
        return _promotions_rewrite_expr(value, available, joins_added, counter, select)

    if isinstance(node, SQLSelect):
        # A select reached in expression position: separate scope for its own
        # aliases (child-selects pass handles it); rewrite with THIS scope's
        # aliases only when it does not shadow them (lateral semantics).
        shadowed = _promotions_bound_aliases(node) & available
        # FIX (AMUX-126 review): a child that binds any NON-INNER join cannot
        # host references to THIS scope's LEFT JOIN aliases — DuckDB rejects
        # correlated non-inner joins. Leave those lookups as subqueries.
        _child_nij = any(
            isinstance(j, SQLJoin) and str(getattr(j, "join_type", "") or "").upper()
            not in ("INNER", "CROSS", "")
            for j in (node.joins or [])
        )
        if not shadowed and not _child_nij:
            node.columns = [_rw(c) for c in (node.columns or [])]
            if node.where is not None:
                node.where = _rw(node.where)
            # Lateral bodies of this child select see the ENCLOSING scope's
            # aliases too — an outer-correlated lookup inside a lateral of a
            # non-shadowing subquery (e.g. inside EXISTS ... CROSS JOIN
            # LATERAL) belongs to THIS scope and its join must land here.
            for join in list(node.joins or []):
                if not isinstance(join, SQLJoin):
                    continue
                if join.on_condition is not None:
                    join.on_condition = _rw(join.on_condition)
                _lat = None
                if isinstance(join.table, SQLSelect):
                    _lat = join.table
                elif isinstance(join.table, SQLSubquery):
                    _lat = join.table.query
                elif isinstance(join.table, SQLAlias) and isinstance(join.table.expr, SQLSelect):
                    _lat = join.table.expr
                if _lat is not None and not (_promotions_bound_aliases(_lat) & available):
                    _lat.columns = [_rw(c) for c in (_lat.columns or [])]
                    if _lat.where is not None:
                        _lat.where = _rw(_lat.where)
        return node
    if _dc.is_dataclass(node) and not isinstance(node, type):
        # Rewrite every field that carries SQL expressions, recursing through
        # nested containers. SQLCase.when_clauses is a list of (cond, result)
        # TUPLES — a flat "list of SQLExpression" scan skips them entirely,
        # which is exactly where the remaining consumer lookups live.
        def _rw_container(v):
            if isinstance(v, SQLExpression):
                return _rw(v)
            if isinstance(v, list):
                return [_rw_container(x) for x in v]
            if isinstance(v, tuple):
                return tuple(_rw_container(x) for x in v)
            return v

        for fname, fval in list(vars(node).items()):
            setattr(node, fname, _rw_container(fval))
        return node
    return node


def _promotions_child_selects(select) -> list:
    """Direct child SQLSelect nodes: every SQLSubquery encountered anywhere
    in the select's expression tree contributes its .query as a child scope.
    Uses generic dataclass-field descent (SQLExists.subquery and similar
    field names are followed)."""
    import dataclasses as _dc

    out: list = []
    seen: set = set()

    def _walk(x, depth=0):
        if (
            depth > 90
            or x is None
            or isinstance(x, (str, int, float, bool, type))
        ):
            return
        if id(x) in seen:
            return
        seen.add(id(x))
        if isinstance(x, SQLSubquery):
            out.append(x.query)
            _walk(x.query, depth + 1)
            return
        if _dc.is_dataclass(x):
            for v in vars(x).values():
                _walk(v, depth + 1)
        elif isinstance(x, (list, tuple)):
            for v in x:
                _walk(v, depth + 1)

    if select is not None:
        if isinstance(select, SQLUnion):
            for arm in select.operands or []:
                if isinstance(arm, SQLSelect):
                    _walk(arm)
                elif isinstance(arm, SQLSubquery):
                    out.append(arm.query)
                    _walk(arm.query)
                elif isinstance(arm, SQLAlias):
                    inner = arm.expr
                    if isinstance(inner, SQLSelect):
                        _walk(inner)
                    elif isinstance(inner, SQLSubquery):
                        out.append(inner.query)
                        _walk(inner.query)
            return out
        _walk(select)
    return out


def _count_promotion_lookups_generic(root) -> int:
    import re as _re
    n = 0
    seen = set()

    def _w(x):
        nonlocal n
        if x is None or isinstance(x, (str, int, float, bool, type)):
            return
        if id(x) in seen:
            return
        seen.add(id(x))
        if isinstance(x, SQLRaw):
            n += len(_re.findall(r"\(SELECT value FROM \"(_fn_|_let_fn_)", x.raw_sql or ""))
            return
        if isinstance(x, SQLSubquery):
            fc = x.query.from_clause if isinstance(x.query, SQLSelect) else None
            if (
                isinstance(fc, SQLAlias)
                and isinstance(fc.expr, SQLIdentifier)
                and fc.expr.name.startswith(("_fn_", "_let_fn_"))
            ):
                n += 1
        import dataclasses as _dc
        if _dc.is_dataclass(x):
            for f in x.__dict__.values():
                _w(f)
        elif isinstance(x, (list, tuple)):
            for f in x:
                _w(f)

    _w(root)
    return n
